/*************************************************************************
 *  File:	SolverTester.java
 *	Class: SolverTester
 *
 *  Generates valid puzzles and writes to database..
 *
 *************************************************************************/
import com.sonpt.colorplace.*;
import java.sql.*;
import java.util.*;
import java.util.Arrays;
import java.util.ArrayList;

public class SolverTester {

    /*
     *  Generates valid puzzles according to the input requirements. The following
     *  parameters are to be passed in the exact order they are presented.
     *      (int)   puzzleSize  the size of the puzzle to solve
     *      (int)   puzzleId    number of givens of the puzzle
     *      (int)   numOfSolutions  number of solutions required
     *      (int)   useLSD      >0 means use, <=0 means don't use LSD
     *      (int)   useALSD     >0 means use, <=0 means don't use ALSD
     *      (int)   normalVsLsd >0 means solving with and without LSD and compare the two, <=0 means ignore
     *      (int)   isPackData  >0 means the puzzle is stored a pack database, which has different structure, <=0 means using library database structure
     *      (String)    puzzlesDb       relative filepath of the puzzles database file
     *
     *  Sample Terminal cmd (Mac): java -classpath ".:sqlite-jdbc-3.8.7.jar" SolverTester 6 12423 -1 1 1 1 -1 ../data/puzzles.db
     */
    public static void main(String[] args) {
        int puzzleSize = Integer.parseInt(args[0]);
        int puzzleId = Integer.parseInt(args[1]);
        int numOfSolutions = Integer.parseInt(args[2]);
        boolean useLSD = (Integer.parseInt(args[3]) > 0) ? true : false;
        boolean useALSD = (Integer.parseInt(args[4]) > 0) ? true : false;
        boolean normalVsLsd = (Integer.parseInt(args[5]) > 0) ? true : false;
        boolean isPackData = (Integer.parseInt(args[6]) > 0) ? true : false;
        String puzzlesDb = args[7];

        // Get the enum Size corresponding to the input.
        Common.Size enumSize = null;
        for (Common.Size size : Common.Size.values()) {
            if (puzzleSize == size.getCode()) {
                enumSize = size;
                break;
            }
        }

        Puzzle puzzle = null;

        // Get the puzzle from the database.
        if (isPackData) {
            Connection packConn = null;
            try {
                packConn = PackData.initPack(puzzlesDb);
            } catch (ClassNotFoundException e) {
                System.err.println(e.getMessage());
            }
            puzzle = PackData.getPuzzle(packConn, puzzleId);
        } else {
            try {
                Data.init(puzzlesDb);
            } catch (ClassNotFoundException e) {
                System.err.println(e.getMessage());
            }
            puzzle = Data.getPuzzleById(enumSize, puzzleId);
        }

        // Convert the puzzle string to a string grid.
        String[][] puzzleGrid = Helper.puzzleStringToStringGrid(puzzle.puzzle);

        if (puzzle == null) {
            System.out.printf("\nCannot find %dx%d puzzle with id %d\n", puzzleSize, puzzleSize, puzzleId);
            return;
        }

        System.out.printf("\nSolving %d x %d puzzle with id %d\n", puzzleSize, puzzleSize, puzzleId);

        if (normalVsLsd) {
            ArrayList<String[][]> solutions_1 = Solver.solve(puzzleGrid, numOfSolutions, false, false, false);   // without LSD
            ArrayList<String[][]> solutions_2 = Solver.solve(puzzleGrid, numOfSolutions, true, useALSD, false);    // with LSD and optionally ALSD

            System.out.println("Checking solutions of no-LSD solver:");
            validateSolutions(solutions_1);

            System.out.println("Checking solutions of LSD-solver:");
            validateSolutions(solutions_2);

            System.out.println("Now compare solutions of the two methods:");
            compareSolutions(solutions_1, solutions_2);
        } else {
            ArrayList<String[][]> solutions_3 = Solver.solve(puzzleGrid, numOfSolutions, useLSD, useALSD, false);
            System.out.printf("\nChecking solutions of solver. useLSD: %s\n", useLSD ? "Yes" : "No");
            validateSolutions(solutions_3);
        }

        // Close database.
        Data.closeDatabase();
    }

    public static void validateSolutions(ArrayList<String[][]> solutions) {
        int i = 0;
        for (String[][] s : solutions) {
            i++;
            boolean success = Validator.validateGrid(s, Common.VALUE_1, Common.VALUE_2);
            System.out.printf("Validated solution #%d: %s\n", i, success ? "Pass" : "Fail");
            Helper.printGrid(s);
        }
    }

    public static void compareSolutions(ArrayList<String[][]> list1, ArrayList<String[][]> list2) {
        for (int i=0; i<list1.size(); i++) {
            String[][] s1 = list1.get(i);
            String[][] s2 = list2.get(i);

            boolean same = Arrays.deepEquals(s1, s2);

            System.out.printf("Checking solution pair #%d: %s\n", i, same ? "Identical" : "Different");
        }
    }

}
