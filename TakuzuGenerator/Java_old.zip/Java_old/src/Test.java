/*************************************************************************
 *  File:	Generator.java
 *	Class: Generator
 *
 *  Generate valid puzzles.
 *
 *
 *************************************************************************/
import com.sonpt.colorplace.*;
import java.util.*;

public class Test {
	private static final int VALUE_1 = 0;
	private static final int VALUE_2 = 1;

    public static void main(String[] args) {
    	
        int gridSize = Integer.parseInt(args[0]);
        int numOfGrids = Integer.parseInt(args[1]);
        int maxAttempts1 = Integer.parseInt(args[2]);
        int maxTrials1 = Integer.parseInt(args[3]);
        int printNum = Integer.parseInt(args[4]);
        int givenNum = Integer.parseInt(args[5]);
        int minPercent = Integer.parseInt(args[6]);
        int maxPercent = Integer.parseInt(args[7]);
        int puzzleNum = Integer.parseInt(args[8]);
        int maxAttempts2 = Integer.parseInt(args[9]);
        int maxTrials2 = Integer.parseInt(args[10]);

        // Get the enum Size corresponding to the input.
        Common.Size enumSize = null;
        for (Common.Size size : Common.Size.values()) {
            if (gridSize == size.getCode()) {
                enumSize = size;
                break;
            }
        }

        // ======================================================================================================================
        // Test working with SQLite database.
        try {
            Data.init("../data/test.db");
        } catch (ClassNotFoundException e) {
            System.err.println(e.getMessage());
        }

        ArrayList<String> excludeGrids = Data.getAllSolutions(enumSize);    // exclude all existing grids in the database.
        ArrayList<String> listOfGrids = Filler.formValidGrids(enumSize.getCode(), VALUE_1, VALUE_2, numOfGrids, maxAttempts1, maxTrials1, excludeGrids);

        Data.insertSolutions(enumSize, listOfGrids);

        ArrayList<String> storedGrids = Data.getAllSolutions(enumSize);
        System.out.println("Now check for repeat solutions in the database...");
        boolean repeatSolution = Validator.repeatStringCheck(storedGrids);

        if (listOfGrids.size()>0) {
            System.out.printf("\nGenerating %d x %d puzzles with %d givens...\n", gridSize, gridSize, givenNum);
            
            // Measure runtime.
            long startTime = System.currentTimeMillis();
            ArrayList<Puzzle> excludePuzzles = Data.getAllPuzzles(enumSize);
            int oldPuzzlesNum = excludePuzzles.size();

            for (int i=0; i<listOfGrids.size(); i++) {
                // Display progress.
                // float percent = (float)(i)*100/listOfGrids.size();
                int puzzlesNum = Data.getPuzzlesNumber(enumSize) - oldPuzzlesNum;
                System.out.println("===========================================================");
                System.out.printf("Generating puzzles for grid #%d of %d; Total puzzles created: %d          \n",i+1, listOfGrids.size(), puzzlesNum);

                String[][] completeGrid = Helper.puzzleStringToStringGrid(listOfGrids.get(i));
                ArrayList<Puzzle> puzzles = Generator.createPuzzles(completeGrid, givenNum, (float) minPercent, (float) maxPercent, puzzleNum, excludePuzzles, maxAttempts2, (long)maxTrials2, true);
                
                Data.insertPuzzles(enumSize, puzzles);
            }

            ArrayList<Puzzle> storedPuzzles = Data.getAllPuzzles(enumSize);
            System.out.println("Now check for repeat puzzles in the database...");
            boolean repeatPuzzle = Validator.repeatPuzzleCheck(storedPuzzles);

            int newPuzzlesNum = storedPuzzles.size();
            int createdPuzzlesNum = newPuzzlesNum - oldPuzzlesNum;
            int requiredPuzzlesNum = puzzleNum*listOfGrids.size();

            // Calculate runtime.
            long stopTime = System.currentTimeMillis();
            long elapsedTime = stopTime - startTime;
            String runtime = Helper.formatTime(elapsedTime);

            System.out.println("\n===========================================================");
            System.out.println("Finished creating puzzles. Statistics:");
            System.out.printf("\nPuzzles specs:\t\t\tsize %dx%d, %d givens, %.0f%% to %.0f%% parseable", gridSize, gridSize, givenNum, (float)minPercent, (float)maxPercent);
            System.out.printf("\nGrids number:\t\t\t%d", listOfGrids.size());
            System.out.printf("\nRequired puzzles/grid:\t\t%d", puzzleNum);
            System.out.printf("\nTotal required puzzles:\t\t%d", requiredPuzzlesNum);
            System.out.printf("\nPuzzles created:\t\t%d (%.2f%%)", createdPuzzlesNum, (float)createdPuzzlesNum*100/requiredPuzzlesNum);
            System.out.printf("\nMax attempts/grid:\t\t%d", maxAttempts2);
            System.out.printf("\nMax trials/attempt:\t\t%d", maxTrials2);
            System.out.printf("\nRepeat puzzle checking result:\t%s", (!repeatPuzzle)? "Pass" : "Fail");
            System.out.printf("\nTime:\t\t\t\t%s", runtime);
            System.out.println("\n===========================================================");
        }

        Data.closeDatabase();

        // ======================================================================================================================
        // // Test generating grids.

        // ArrayList<String> excludeGrids = new ArrayList<String>();
        // ArrayList<String> listOfGrids = Filler.formValidGrids(gridSize, VALUE_1, VALUE_2, numOfGrids, maxAttempts1, maxTrials1, excludeGrids);

        // Validator.repeatStringCheck(listOfGrids);

        // int numToPrint = (printNum<0)? listOfGrids.size() : (printNum > listOfGrids.size())? listOfGrids.size() : printNum;

        // System.out.println("List of constructed grids:");
        // System.out.println("===========================================================");
        // for (int i=0; i<numToPrint; i++) {
        //     String[][] grid = Helper.puzzleStringToStringGrid(listOfGrids.get(i));
        //     boolean validated = Validator.validateGrid(grid, Common.VALUE_1, Common.VALUE_2);
        //     System.out.printf("Grid number: %d (validated: %b)\n", i+1, validated);            
        //     Helper.printGrid(grid);
        //     System.out.println("===========================================================");
        // }

        // if (listOfGrids.size()>0) {
        //     System.out.println("Now generate puzzles from the above grid...");

        //     String[][] completeGrid = Helper.puzzleStringToStringGrid(listOfGrids.get(0));
        //     ArrayList<Puzzle> excludePuzzles = new ArrayList<Puzzle>();
        //     ArrayList<Puzzle> puzzles = Generator.createPuzzles(completeGrid, givenNum, (float) minPercent, (float) maxPercent, puzzleNum, excludePuzzles, maxAttempts2, (long)maxTrials2, false);

        //     Validator.repeatPuzzleCheck(puzzles);

        //     for (int i=0; i<puzzles.size(); i++) {
        //         Puzzle p = puzzles.get(i);
        //         String[][] pGrid = Helper.puzzleStringToStringGrid(p.puzzle);
        //         int parseNum = p.parseNum;
        //         float parsePercent = p.parsePercent;
        //         int level = p.level;
        //         System.out.printf("\nPuzzle number %d", (i+1));
        //         System.out.printf("\nParseNum: %d (%.2f %%); level: %d\n", parseNum, parsePercent, level);
        //         Helper.printGrid(pGrid);
        //     }
        // }

        // ======================================================================================================================
        // // Test solving puzzle.

        String grid_14_str =    "01001011010110" +
                                "01010010101101" +
                                "10101100110010" +
                                "10010101001101" +
                           "01010011011010" +
                           "10101100100101" +
                           "00110100110011" +
                           "11010011001010" +
                           "01101101001100" +
                           "00101100110011" +
                           "10010011001101" +
                           "01101010110010" +
                           "10110100110100" +
                           "11001011001001";


        String med_14_p =   ".01....01....1" +
                            "0....11......1" +
                            ".1........1.0." +
                            ".1...........0" +
                            "..0.0..0....0." +
                            "1....1...00..." +
                            "..........0.0." +
                            ".0...........0" +
                            ".0....10.1..1." +
                            "....0.....0..." +
                            "0.....1..0...0" +
                            "..0.....0...1." +
                            "..0..0........" +
                            "...1..00.00.1.";

        String med_14_s =   "10101010101001" +
                            "00110110010011" +
                            "11001001101100" +
                            "01101001010110" +
                            "10010110011001" +
                            "11010100100110" +
                            "01101001100101" +
                            "00101011011010" +
                            "10010110011010" +
                            "01010101100101" +
                            "01101010101100" +
                            "10010101010011" +
                            "01001011011001" +
                            "10110100100110";

        String grid_6_str =   "010110" +
                            "011001" +
                            "101001" +
                            "010110" +
                            "101010" +
                            "100101";

        String easy_6_p =       ".....1" +
                                ".....1" +
                                "..1.0." +
                                "......" +
                                "1..00." +
                                ".0..0.";                 
        
        String easy_6_s =       "010011" +
                                "010011" +
                                "101100" +
                                "010110" +
                                "101001" +
                                "101100";

        String easy_6_p2 =      ".0...." +
                                ".1...." +
                                "0...0." +
                                ".1.00." +
                                ".0...." +
                                "...1.1";                 
        
        String easy_6_s2 =      "101010" +
                                "110010" +
                                "001101" +
                                "011001" +
                                "100110" +
                                "010101";

        String med_6_p =        ".....0" +
                                "..11.." +
                                "00...." +
                                "...0.." +
                                "......" +
                                "0.0..0";                 
        
        String med_6_s =        "";

        // String med_10_p =       "0........0" +
        //                         ".0..1.1..." +
        //                         "...11.1..." +
        //                         "...1...0.." +
        //                         "11....0..." +
        //                         "..11....1." +
        //                         "0.....0..." +
        //                         ".1....0.1." +
        //                         "...11..00." +
        //                         "...1.1....";

        String med_10_p =       "0........0" +
                                ".0..1.1..." +
                                "...1..1..." +
                                "...1...0.." +
                                "11....0..." +
                                "..11....1." +
                                "0.....0..." +
                                ".1....0.1." +
                                "...11..00." +
                                "...1.1....";

        String med_10_s =       "0........0" +
                                ".0..1.1..." +
                                "...11.1..." +
                                "...1...0.." +
                                "11....0..." +
                                "..11....1." +
                                "0.....0..." +
                                ".1....0.1." +
                                "...11..00." +
                                "...1.1....";

        String med_14_p2 =  ".........0.1.." +
                            "00.1.1........" +
                            ".....1..10..1." +
                            ".11.....1....." +
                            ".0..0....0..10" +
                            "......1...0..." +
                            "1.....0.1....." +
                            ".10..1.....1.." +
                            ".............." +
                            "0..0.1.00....." +
                            "....0.00...1.." +
                            "0..1.........." +
                            ".............0" +
                            "..11...11.11..";

        String med_14_s2 =  ".........0.1.." +
                            "00.1.1........" +
                            ".....1..10..1." +
                            ".11.....1....." +
                            ".0..0....0..10" +
                            "......1...0..." +
                            "1.....0.1....." +
                            ".10..1.....1.." +
                            ".............." +
                            "0..0.1.00....." +
                            "....0.00...1.." +
                            "0..1.........." +
                            ".............0" +
                            "..11...11.11..";

        String extreme_8_p =    "..1..1.." +
                                ".......0" +
                                "....0..." +
                                ".0...1.." +
                                "1..1...1" +
                                "......0." +
                                "...00..." +
                                "11......";
                    

        String med_18_s =  "010110011010100110" +
                            "110110010100110010" +
                            "101001101001011001" +
                            "001010110110100110" +
                            "110101010100101010" +
                            "101001001011010101" +
                            "010010101100110101" +
                            "001101010101101010" +
                            "110010010010011011" +
                            "011010101101010100" +
                            "001101100110101001" +
                            "110010011011010010" +
                            "011010101100110100" +
                            "100101010011001011" +
                            "001101101001001101" +
                            "011010100110110010" +
                            "100101010011001101" +
                            "100101101001001101";
        
        // String pz = med_18_s, s = med_10_s;

        // String[][] grid = Helper.puzzleStringToStringGrid(pz);
        // int size = grid.length;

        // ArrayList<String[][]> solutions = Solver.solve(grid, -1, false);

        // for (int i=0; i<solutions.size(); i++) {
        //     String[][] solution = solutions.get(i);
        //     boolean validated = Validator.validateGrid(solution, Common.VALUE_1, Common.VALUE_2);

        //     System.out.printf("Solution number: %d (validated: %b)\n", i, validated);
        //     Helper.printGrid(solution);
        // }

        // Validator.repeatStringArraysCheck(solutions);

        // System.out.println("Now generate puzzles from the above solutions...");

        // ArrayList<String[][]> puzzles = Generator.createPuzzles(grid, givenNum, (float) minPercent, (float) maxPercent, puzzleNum, maxAttempts2, (long)maxTrials2, false);

        // for (int i=0; i<puzzles.size(); i++) {
        //     String[][] p = puzzles.get(i);
        //     Solver.solve(p, -1, true);
        //     int parsedCells = Solver.numOfParsedCells;
        //     float percent = (float)parsedCells*100/(p.length*p.length);
        //     System.out.printf("\nPuzzle number %d", (i+1));
        //     System.out.printf("\nCells solved by parsing: %d (%.2f %%)\n", parsedCells, percent);
        //     Helper.printGrid(p);
        // }

        // ======================================================================================================================
        // // Test copy arrays.
        // // Test result: changing an array or it copy will change both.

        // String[][] strArray = {
        //     {"1", "2", "3"},
        //     {"4", "5", "6"},
        //     {"7", "8", "9"}
        // };

        // String[][] strArrayCopy = Arrays.copyOf(strArray, strArray.length);

        // ArrayList<String[][]> arrList = new ArrayList<String[][]>();
        // arrList.add(strArrayCopy);

        // System.out.println("Original strArray:");
        // Helper.printGrid(strArray);

        // System.out.println("Original strArrayCopy:");
        // Helper.printGrid(strArrayCopy);

        // System.out.println("strArrayCopy in list:");
        // Helper.printGrid(arrList.get(0));

        // String[] newRow = {"10", "11", "12"};

        // strArray[2] = newRow;

        // System.out.println("strArray was modified.");

        // System.out.println("New strArray:");
        // Helper.printGrid(strArray);

        // System.out.println("New strArrayCopy:");
        // Helper.printGrid(strArrayCopy);

        // System.out.println("New strArrayCopy in list:");
        // Helper.printGrid(arrList.get(0));

        // // Repeat the test with primitive values.
        // int[][] strArray = {
        //     {1, 2, 3},
        //     {4, 5, 6},
        //     {7, 8, 9}
        // };

        // // int[][] strArrayCopy = Arrays.copyOf(strArray, strArray.length);

        // int[][] strArrayCopy = Helper.deepCopyOfGrid(strArray);

        // System.out.println("Original strArray:");
        // Helper.printGrid(strArray);

        // System.out.println("Original strArrayCopy:");
        // Helper.printGrid(strArrayCopy);

        // int[] newRow = {10, 11, 12};

        // strArray[2][2] = 10;

        // System.out.println("strArray was modified.");

        // System.out.println("New strArray:");
        // Helper.printGrid(strArray);

        // System.out.println("New strArrayCopy:");
        // Helper.printGrid(strArrayCopy);

        // ======================================================================================================================
        // // Test Classes methods.

        // int[] posArray = new int[gridSize];  // array contains position numbers in a line: 1,2,3,4,etc.
        // for (int i=0; i<gridSize; i++) {
        //  posArray[i] = i;
        // }

        // ArrayList<int[]> validLines = Filler.findValidLines(posArray, VALUE_1, VALUE_2);


        // // To find all arrangements where the number of blue and white color cells are equal in a line,
        // // we only need to find all combinations of (halfSize) elements from (gridSize) positions
        // // available in the line (in other words, find ways to put (halfSize) blue cells into the line).
        // ArrayList<int[]> combinations = Filler.findCombinations(posArray, halfSize);

        // System.out.println("===========================================================");
        // System.out.println("Number of combinations: " + combinations.size());
        // System.out.println("===========================================================");

        // for (int j=0; j<combinations.size(); j++) {
        //  int[] subset = (combinations.get(j));
        //  System.out.println(Arrays.toString(subset) + " at index: " + combinations.indexOf(subset));
        // }

        // int[][] lines = {
        //  {0,1,1},
        //  {},
        //  {0,1,1,1},
        //  {0,1,0,1},
        //  {0,0,0,1,1,1},
        //  {0,1,0,0,1,0},
        //  {0,0,0,0,1,1},
        //  {0,1,1,0,0,1}
        // };

        // for (int k=0; k<lines.length; k++) {
        //  int[] line = lines[k];
        //  boolean condition1 = Validator.tripletCheck(line, 0, 1);
        //  boolean condition2 = Validator.equalityCheck(line, 0, 1);
        //  boolean valid = Validator.validateLine(line, 0, 1);

        //  System.out.println("===========================================================");
        //  System.out.println("Checking line: " + k);
        //  System.out.println("Line values: " + Arrays.toString(line));
        //  System.out.println("tripleCheck result: " + condition1);
        //  System.out.println("equalityCheck result: " + condition2);
        //  System.out.println("validateLine result: " + valid);
        // }

        // ======================================================================================================================
        // // Test string manipulation.

        // String str1 = "TestStr";
        // String str2 = str1.replace('S', 'x');

        // System.out.println("Original str: " + str1);
        // System.out.println("Replaced str: " + str2);

        // String[][] strArray = {
        //     {"This", "is", "a"},
        //     {"test", "string", "array"}
        // };

        // String elStr = strArray[1][0];

        // System.out.println("Original string array:");
        // for (int row=0; row < strArray.length; row++) {
        //      System.out.println(Arrays.toString(strArray[row]));
        // }

        // System.out.println("Original elStr: " + elStr);

        // elStr = "New String";

        // System.out.println("Assigned elStr a new value...");
        // System.out.println("New elStr: " + elStr);


        // System.out.println("New string array:");
        // for (int row=0; row < strArray.length; row++) {
        //      System.out.println(Arrays.toString(strArray[row]));
        // }

        // String testStr = "01";
        // System.out.println("Original str: " + testStr);
        // System.out.println("String length: " + testStr.length());

        // StringBuilder sb = new StringBuilder(testStr);

        // int index = sb.indexOf("2");
        // System.out.println("Index of 2: " + index);
        
        // // String str1 = sb.deleteCharAt(index).toString();
        // // System.out.println("String after replace '2': " + str1);

        // int index1 = sb.indexOf("1");
        // System.out.println("Index of 1: " + index1);

        // String str2 = sb.deleteCharAt(index1).toString();
        // System.out.println("String after replace '1': " + str2);
        // System.out.println("String length: " + str2.length());

        // StringBuilder sb2 = new StringBuilder(str2);

        // int index2 = sb2.indexOf("1");
        // System.out.println("Index of 1: " + index2);

        // // String str3 = sb2.deleteCharAt(index1).toString();
        // // System.out.println("String after replace '1' one more time: " + str3);
        // // System.out.println("String length: " + str3.length());

        // int index3 = sb2.indexOf("0");
        // System.out.println("Index of 0: " + index3);

        // str2 = sb2.deleteCharAt(index3).toString();
        // System.out.println("String after replace '0': " + str2);
        // System.out.println("String length: " + str2.length());

        // ======================================================================================================================
        // // Test loop local variable scope.

        // ArrayList<int[]> testList1 = new ArrayList<int[]>();
        // ArrayList<int[]> testList2 = new ArrayList<int[]>();
        
        // int[] outArray = new int[3];
        // for (int i=0; i<6; i++) {
        //     outArray[0] = i;
        //     outArray[1] = i+1;
        //     outArray[2] = i+2;
        //     int[] inArray = {i, i+1, i+2};

        //     testList1.add(outArray);
        //     testList2.add(inArray);
        // }

        // System.out.println("testList1:");
        // for (int[] array : testList1) {
        //     System.out.println(Arrays.toString(array));
        // }

        // System.out.println("testList2:");
        // for (int[] array : testList2) {
        //     System.out.println(Arrays.toString(array));
        // }

        // ======================================================================================================================
        // // Test comparing 2D arrays.

        // int[][] array1 = {
        // 	{1,2,3},
        // 	{4,5,6},
        // 	{7,8,9}
        // };

        // String[][] array2 = {
        //     {"1","2","3"},
        //     {"4","5","6"},
        //     {"7","8","9"}
        // };

        // System.out.println("Print array by Helper method");
        // Helper.printGrid(array1);
        // System.out.println("===========================================================");
        // Helper.printGrid(array2);

        // int[][] array2 = {
        // 	{1,2,3},
        // 	{4,5,6},
        // 	{7,8,0}
        // };

        // int[][] array3 = {
        // 	{1,2,3},
        // 	{4,5,6},
        // 	{7,8,3}
        // };

        // int[][] array4 = {
        // 	{1,2,3},
        // 	{4,5,6}
        // };

        // int[][] array5 = {};

        // ArrayList<int[][]> list = new ArrayList<int[][]>();

        // list.add(array1);
        // list.add(array2);
        // list.add(array3);
        // list.add(array4);
        // list.add(array5);

        // boolean repeat = Validator.repeatElementsCheck(list);

        // System.out.println("List contains repeat elements?: " + repeat);

        // System.out.println("array1 == array2?: " + Arrays.deepEquals(array1, array2));
        // System.out.println("array1 == array3?: " + Arrays.deepEquals(array1, array3));
        // System.out.println("array1 == array4?: " + Arrays.deepEquals(array1, array4));
        // System.out.println("array1 == array5?: " + Arrays.deepEquals(array1, array5));

        // ======================================================================================================================
        // // Test generating shuffle list.

        // int[] shuffle = Helper.createShuffleList(10);
        // System.out.println("Shuffle list of size: " + shuffle.length);
        // System.out.println(Arrays.toString(shuffle));
        
        // ======================================================================================================================
        // // Test checking array containing element.

        // int[][] array1 = {
        // 	{1,2,3},
        // 	{4,5,6}
        // };

        // int[][] array2 = {
        // 	{7,8,9},
        // 	{10,11,12}
        // };

        // ArrayList<int[][]> list = new ArrayList<int[][]>();
        // list.add(Arrays.copyOf(array1, array1.length));
        // list.add(array2);

        // System.out.println("===========================================================");
        // System.out.println("List contains array1: " + list.contains(array1));
        // System.out.println("List contains array2: " + list.contains(array2));

        // System.out.println("Old array2:");

        // for (int row=0; row < array2.length; row++) {
        // 	System.out.println(Arrays.toString(array2[row]));
        // }

        // array2[1] = list.get(0)[1];

        // System.out.println("New array2:");

        // for (int row=0; row < array2.length; row++) {
        // 	System.out.println(Arrays.toString(array2[row]));
        // }
        
        // System.out.println("List contains new array2: " + list.contains(array2));

        // int[] array3 = {array2[0][1], array2[1][1]};

        // System.out.println("array3:");
        // System.out.println(Arrays.toString(array3));

        // ======================================================================================================================
        // // Test copy 1 row from one array to another.
        // int[] array4 = array1[0];
        // System.out.println("array4: " + Arrays.toString(array4));

        // // Test deep copy of 2d arrays.
        // int[][] array5 = Arrays.copyOf(array2, array2.length);

        // System.out.println("array5 (copy of array2):");
        // for (int row=0; row < array5.length; row++) {
        // 	System.out.println(Arrays.toString(array5[row]));
        // }

        // // Now change array2 and see if array5 changes.
        // array2[1] = list.get(0)[0];

        // System.out.println("array2 now is:");

        // for (int row=0; row < array2.length; row++) {
        // 	System.out.println(Arrays.toString(array2[row]));
        // }

        // System.out.println("array5 now is:");
        // for (int row=0; row < array5.length; row++) {
        // 	System.out.println(Arrays.toString(array5[row]));	// test result: changing on original array won't affect copy of it.
        // }

        // ======================================================================================================================
        // // Test deep copy of 3d arrays.
        // int[][][] array6 = {
        // 	{
        // 		{1,2},
        // 		{3,4}
        // 	},
        // 	{
        // 		{5,6},
        // 		{7,8}
        // 	}
        // };

        // System.out.println("array6 (3d array):");
        // for (int i=0; i < array6.length; i++) {
        // 	for (int j=0; j < array6[i].length; j++) {
        // 		System.out.println(Arrays.toString(array6[i][j]));	// test result: changing on original array won't affect copy of it.
        // 	}
        // }

        // int[][][] array7 = Arrays.copyOf(array6, array6.length);

        // System.out.println("array7 (3d array copy of array6):");
        // for (int i=0; i < array7.length; i++) {
        // 	for (int j=0; j < array7[i].length; j++) {
        // 		System.out.println(Arrays.toString(array7[i][j]));	// test result: changing on original array won't affect copy of it.
        // 	}
        // }

        // // Test contain checking of strings.
        // ArrayList<String> list2 = new ArrayList<String>();
        // String str1 = "Hello Java";
        // String str2 = "Hello Java";
        // String str3 = "Hello Java2";

        // list2.add(str1);

        // System.out.println("List contains str1: " + list2.contains(str1));
        // System.out.println("List contains str2: " + list2.contains(str2));
        // System.out.println("List contains str3: " + list2.contains(str3));
        // System.out.println("List size: " + list2.size());

        // list2.add(str3);

        // System.out.println("Added str3 to list");
        // System.out.println("List contains str3: " + list2.contains(str3));
        // System.out.println("List size now: " + list2.size());
    }

}
