/*************************************************************************
 *  File:	Helper.java
 *	Class: 	Helper
 *
 *  Useful utilites.
 *
 *************************************************************************/
package com.sonpt.colorplace;

import java.util.*;
import java.util.concurrent.TimeUnit;

public class Helper {

    //constructor
	public Helper() {
		
	}

	/*
	 * 	Returns array list of all cell indices (row and column indices) of all triplets
	 *	in the squared 2D grid of gridSize that contains the target cell specified by row and column.
	 */
	public static ArrayList<int[][]> getTripletsIndices(int gridSize, int row, int col) {
		ArrayList<int[][]> triplets = new ArrayList<int[][]>();

		// Simple way to find cell's triplets is to iterate through all the triplets
		// within the cell's row and column and detect those that contains the target cell
		// (by checking the indices of the cells).
		for (int i=0; i<=gridSize-3; i++) {
			// Get the indices of 3 cells in each triplet.
			int first = i;
			int middle = i+1;
			int last = i+2;

			if ((col==first) || (col==middle) || (col==last)) {
				int[][] rowTriplet = {
					{row, first}, {row, middle}, {row, last}
				};
				triplets.add(rowTriplet);
			}

			if((row==first) || (row==middle) || (row==last)) {
				int[][] colTriplet = {
					{first, col},
					{middle, col},
					{last, col}
				};
				triplets.add(colTriplet);
			}
		}

		return triplets;
	}

	/*
	 *	Returns the array list of all cell values (as opposed to indices in the above method)
	 *	of all triplets in the squared 2D grid that contains the target cell specified by row and column.
	 */
	public static ArrayList<int[]> getTriplets(int[][] grid, int row, int col) {
		ArrayList<int[]> triplets = new ArrayList<int[]>();

		// Get the row and column crossing the target cell.
		int[] rowArray = getRow(grid, row);
		int[] colArray = getCol(grid, col);

		// Simple way to find cell's triplets is to iterate through all the triplets
		// within the cell's row and column and detect those that contains the target cell
		// (by checking the indices of the cells).
		for (int c=0; c<=rowArray.length-3; c++) {
			// Get the indices of 3 cells in the triplet.
			int first = c;
			int middle = c+1;
			int last = c+2;

			if ((col==first) || (col==middle) || (col==last)) {
				int[] triplet = {rowArray[first], rowArray[middle], rowArray[last]};
				triplets.add(triplet);
			}
		}

		for (int r=0; r<colArray.length-3; r++) {
			int first = r;
			int middle = r+1;
			int last = r+2;

			if((row==first) || (row==middle) || (row==last)) {
				int[] triplet = {colArray[first], colArray[middle], colArray[last]};
				triplets.add(triplet);
			}
		}

		return triplets;
	}

	public static ArrayList<String[]> getTriplets(String[][] grid, int row, int col) {
		ArrayList<String[]> triplets = new ArrayList<String[]>();

		// Get the row and column crossing the target cell.
		String[] rowArray = getRow(grid, row);
		String[] colArray = getCol(grid, col);

		// Simple way to find cell's triplets is to iterate through all the triplets
		// within the cell's row and column and detect those that contains the target cell
		// (by checking the indices of the cells).
		for (int c=0; c<=rowArray.length-3; c++) {
			// Get the indices of 3 cells in the triplet.
			int first = c;
			int middle = c+1;
			int last = c+2;

			if ((col==first) || (col==middle) || (col==last)) {
				String[] triplet = {rowArray[first], rowArray[middle], rowArray[last]};
				triplets.add(triplet);
			}
		}

		for (int r=0; r<colArray.length-3; r++) {
			int first = r;
			int middle = r+1;
			int last = r+2;

			if((row==first) || (row==middle) || (row==last)) {
				String[] triplet = {colArray[first], colArray[middle], colArray[last]};
				triplets.add(triplet);
			}
		}

		return triplets;
	}

	/*
	 *	Returns array of the specified row of a squared 2D grid.
	 */
	public static int[] getRow(int[][] grid, int row) {
		int size = grid.length;
		int[] array = new int[size];

		for (int col=0; col<size; col++) {
			array[col] = grid[row][col];
		}

		return array;
	}

	public static String[] getRow(String[][] grid, int row) {
		int size = grid.length;
		String[] array = new String[size];

		for (int col=0; col<size; col++) {
			array[col] = grid[row][col];
		}

		return array;
	}

	/*
	 *	Returns array of the specified column of a squared 2D grid.
	 */
	public static int[] getCol(int[][] grid, int col) {
		int size = grid.length;
		int[] array = new int[size];

		for (int row=0; row<size; row++) {
			array[row] = grid[row][col];
		}

		return array;
	}

	public static String[] getCol(String[][] grid, int col) {
		int size = grid.length;
		String[] array = new String[size];

		for (int row=0; row<size; row++) {
			array[row] = grid[row][col];
		}

		return array;
	}

	/*
	 *	Parses string content and returns a new grid (2D array) ot int values, each
	 *	grid element is the numeric value of corresponding character of the input string.
	 */
	public static int[][] puzzleStringToIntGrid(String str) {

		double pSize = Math.sqrt(str.length());
		boolean valid = isValidPuzzleSize(pSize);

		if (!valid) {
			throw new IllegalArgumentException();
		}

		int size = (int)pSize;
		int[][] array = new int[size][size];

		for (int i=0; i<str.length(); i++) {
			int row = i/size;
			int col = i%size;

			array[row][col] = Character.getNumericValue(str.charAt(i));
		}

		return array;
	}

	/*
	 *	Parses string content and returns a new grid (2D array) ot String, each
	 *	grid element is a String object of corresponding character of the input string.
	 */
	public static String[][] puzzleStringToStringGrid(String str) {

		double pSize = Math.sqrt(str.length());
		boolean valid = isValidPuzzleSize(pSize);

		if (!valid) {
			throw new IllegalArgumentException();
		}
		
		int size = (int)pSize;
		String[][] array = new String[size][size];

		for (int i=0; i<str.length(); i++) {
			int row = i/size;
			int col = i%size;

			array[row][col] = str.substring(i,i+1);
		}

		return array;
	}

	/*
	 *	Converts a String grid (2D array) to a String.
	 */
	public static String puzzleStringGridToString(String[][] grid) {
		int len = grid.length*grid.length;
		StringBuffer strbuf = new StringBuffer(len);

		for (int row=0; row<grid.length; row++) {
			for (int col=0; col<grid[row].length; col++) {
				strbuf.append(grid[row][col]);
			}
		}
		return strbuf.toString();
	}

	/*
	 *	Converts a int grid to a String.
	 */
	public static String puzzleIntGridToString(int[][] grid) {
		int len = grid.length*grid.length;
		StringBuffer strbuf = new StringBuffer(len);

		for (int row=0; row<grid.length; row++) {
			for (int col=0; col<grid[row].length; col++) {
				String s = Integer.toString(grid[row][col]);
				strbuf.append(s);
			}
		}
		return strbuf.toString();
	}

	/*
	 *	Converts int[][] grid to String[][] grid. 
	 */
	public static String[][] intGridToStringGrid(int[][] grid) {

		int size = grid.length;
		String[][] result = new String[size][size];

		for (int r=0; r<grid.length; r++) {
			for (int c=0; c<grid[r].length; c++) {
				result[r][c] = Integer.toString(grid[r][c]);
			}
		}

		return result;
	}

	/*
	 *	Checks if the given size satisfies all size requirements of this game.
	 *	Returns true if satisfies, false otherwise.
	 */
	public static boolean isValidPuzzleSize(double size) {
		boolean valid = true;

		// For this kind of puzzle, puzzle size must be a mathematical integer and even number.
		// Moreover, puzzle size must be at least 4 (4x4 grid) for the puzzle to be meaningful.
		if (size!=Math.ceil(size)) {
			System.out.println("Invalid puzzle string: non-integer puzzle size calculated.");
			valid = false;
		} else if ((size%2)!=0) {
			System.out.println("Invalid puzzle string: puzzle size is odd.");
			valid = false;
		} else if (size<4) {
			System.out.println("Invalid puzzle string: puzzle size smaller than 4x4.");
			valid = false;
		}

		return valid;
	}


    /*
	 *	Displays the 2D puzzle grid.
	 */
	public static void printGrid(String[][] grid) {
		for (int row=0; row < grid.length; row++) {
			String rowStr = "|";
        	for (int col=0; col < grid.length; col++) {
        		String val = grid[row][col];
        		val = (val.equals(Common.DEFAULT_VALUE)) ? Common.DOT : val; 	// Replace default value with dot for better visibility.
        		val = (val.length()>1)? val : (val + " ");
        		rowStr += " " + val + " |";
        	}
        	System.out.println(rowStr);
        	String line = "";
        	for (int i=0; i<rowStr.length(); i++) {
        		line += "-";
        	}
        	System.out.println(line);
        }
	}

	public static void printGrid(int[][] grid) {
		for (int row=0; row < grid.length; row++) {
			String rowStr = "|";
        	for (int col=0; col < grid.length; col++) {
        		rowStr += "  " + grid[row][col] + "  |";
        	}
        	System.out.println(rowStr);
        	String line = "";
        	for (int i=0; i<rowStr.length(); i++) {
        		line += "_";
        	}
        	System.out.println(line);
        }
	}

    /*
     *  Creates a shuffle array of integer values from 0->(size-1).
     */
    public static int[] createShuffleList(int size) {
        Random rand = new Random();
        int[] shuffle = new int[size];

        // Initialize the list.
        for (int i=0; i<shuffle.length; i++) {
            shuffle[i] = i;
        }

        // Now shuffle list.
        for (int j=shuffle.length-1; j>0; j--) {
            int k = rand.nextInt(j);

            int temp = shuffle[j];
            shuffle[j] = shuffle[k];
            shuffle[k] = temp;
        }

        return shuffle;
    }

    /*
     * Creates a deep copy of a 2D array.
     * Returns the copy 2D array of the given array.
     */
    public static int[][] deepCopyOfGrid(int[][] grid) {
    	int row = grid.length, col = grid[0].length;
    	int[][] copy = new int[row][col];
    	for (int i=0; i<row; i++) {
    		for (int j=0; j<col; j++) {
    			copy[i][j] = grid[i][j];
    		}
    	}
    	return copy;
    }

    public static String[][] deepCopyOfGrid(String[][] grid) {
    	int row = grid.length, col = grid[0].length;
    	String[][] copy = new String[row][col];
    	for (int i=0; i<row; i++) {
    		for (int j=0; j<col; j++) {
    			copy[i][j] = grid[i][j];
    		}
    	}
    	return copy;
    }

    /*
     * Creates a deep copy of a 1D array.
     * Returns the copy array of the given array.
     */
    public static int[] deepCopyOfArray(int[] line) {
    	int size = line.length;
    	int[] copy = new int[size];
    	for (int i=0; i<size; i++) {
    		copy[i] = line[i];
    	}
    	return copy;
    }

    public static String[] deepCopyOfArray(String[] line) {
    	int size = line.length;
    	String[] copy = new String[size];
    	for (int i=0; i<size; i++) {
    		copy[i] = line[i];
    	}
    	return copy;
    }

    /*
     *  Checks if the given array contains an int value.
     *  Returns true if contains, false otherwise.
     */
    public static boolean arrayContains(int[] array, int value) {
        boolean contained = false;

        for (int i=0; i<array.length; i++) {
            if(value==array[i]) {
                contained = true;
                break;
            }
        }

        return contained;
    }

    /*
     *  Checks if the given ArrayList of Integer contains an int value.
     *  Returns true if contains, false otherwise.
     */
    public static boolean arrayContains(ArrayList<Integer> array, int value) {
        boolean contained = false;

        for (int i=0; i<array.size(); i++) {
            if(value==array.get(i)) {
                contained = true;
                break;
            }
        }

        return contained;
    }

    /*
     *  Converts milliseconds to hour, min, sec format.
     *  Returns String of the formatted time.
     */
    public static String formatTime(long millis) {
        long hours = TimeUnit.MILLISECONDS.toHours(millis);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(hours);
        long seconds = TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.HOURS.toSeconds(hours) - TimeUnit.MINUTES.toSeconds(minutes);
        long milliseconds = millis - TimeUnit.HOURS.toMillis(hours) - TimeUnit.MINUTES.toMillis(minutes) - TimeUnit.SECONDS.toMillis(seconds);

        String format = String.format("%d hour, %d min, %d sec, %d millis.", hours, minutes, seconds, milliseconds);

        return format;
    }

    /*  
     *  Finds all combinations (sub-arrays) of length len from the parent array inputArray.
     *  Returns the ArrayList contains all sub-arrays found.
     */
    public static ArrayList<int[]> findCombinations(int[] inputArray, int len) {
        ArrayList<int[]> combinationList = new ArrayList<int[]>();
        int[] combination = new int[len];

        // System.out.println("Finding all possible combinations...");

        combinations(inputArray, len, 0, combination, combinationList);

        return combinationList;
    }

    /*
     * Private functions that actually performs the searching of combinations.
     */
    private static void combinations(int[] inputArray, int len, int startPosition, int[] subset, ArrayList<int[]> list){
        if (len == 0) {  
            // System.out.println(Arrays.toString(subset));
            list.add(Arrays.copyOf(subset, subset.length)); // note that we need to create a copy since subset is to change the next iteration.
            return;
        }       
        for (int i = startPosition; i <= inputArray.length-len; i++) {
            subset[subset.length - len] = inputArray[i];
            combinations(inputArray, len-1, i+1, subset, list);
        }
    }
}
