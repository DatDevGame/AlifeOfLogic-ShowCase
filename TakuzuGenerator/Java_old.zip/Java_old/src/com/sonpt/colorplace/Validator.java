/*************************************************************************
 *  File:	Validator.java
 *	Class: 	Validator
 *
 *  Detects 3-in-a-row or inequality of values in grid or array.
 *
 *************************************************************************/
package com.sonpt.colorplace;

import java.util.Arrays;
import java.util.ArrayList;

public class Validator {

    //constructor
	public Validator() {
		
	}

	/*
	 * 	Checks if a grid (2d array) satisfies two game rules: no 3-in-a-row and
	 * 	equal numbers of filled values.
	 *	Returns true if satisfies, false otherwise.
	 */
	public static boolean validateGrid(int[][] grid, int value1, int value2) {
		boolean valid = true;
		int size = grid.length;

		// Iterate through all cells on the diagonal of the grid, get all the 
		// rows and columns that cross at each cell and validate them.
		for (int i=0; i<size; i++) {
			// Check row i.
			int[] row = Helper.getRow(grid, i);
			boolean rowCheck = validateLine(row, value1, value2);

			if (!rowCheck) {
				valid = false;
				break;
			}

			// Check column i.
			int[] col = Helper.getCol(grid, i);
			boolean colCheck = validateLine(col, value1, value2);

			if (!colCheck) {
				valid = false;
				break;
			}
		}

		return valid;
	}

	public static boolean validateGrid(String[][] grid, String value1, String value2) {
		boolean valid = true;
		int size = grid.length;

		// Iterate through all cells on the diagonal of the grid, get all the 
		// rows and columns that cross at each cell and validate them.
		for (int i=0; i<size; i++) {
			// Check row i.
			String[] row = Helper.getRow(grid, i);
			boolean rowCheck = validateLine(row, value1, value2);

			if (!rowCheck) {
				valid = false;
				break;
			}

			// Check column i.
			String[] col = Helper.getCol(grid, i);
			boolean colCheck = validateLine(col, value1, value2);

			if (!colCheck) {
				valid = false;
				break;
			}
		}

		return valid;
	}

	/*
	 *	Checks if an array satisfies two conditions: no 3-in-a-row and equality.
	 *	Returns true if satisfies, false otherwise.
	 */
	public static boolean validateLine(int[] inputArray, int value1, int value2) {
		boolean	condition1 = tripletCheck(inputArray, value1, value2);
		boolean condition2 = equalityCheck(inputArray, value1, value2);

		boolean result;
		if (condition1 && condition2) result = true;
		else result = false;

		return result;
	}

	public static boolean validateLine(String[] inputArray, String value1, String value2) {
		boolean	condition1 = tripletCheck(inputArray, value1, value2);
		boolean condition2 = equalityCheck(inputArray, value1, value2);

		boolean result;
		if (condition1 && condition2) result = true;
		else result = false;

		return result;
	}

	/*
	 *	Checks if there's at least one 3-in-a-row triplet of the same value in the input array.
	 *	Returns true if there's no 3-in-a-row found, false otherwise.
	 */ 
	public static boolean tripletCheck(int[] inputArray, int value1, int value2) {
		boolean result = true;

		if (inputArray.length < 3) {
			result = true;
		} else {
			for (int i=0; i<=inputArray.length-3; i++) {
				int first = inputArray[i];
				int middle = inputArray[i+1];
				int last = inputArray[i+2];

				if ((first==middle && middle==last) && (first==value1 || first==value2)) {
					result = false;	// found 3-in-a-row triplet of the same value.
					break;
				}
			}
		}
		return result;
	}

	public static boolean tripletCheck(String[] inputArray, String value1, String value2) {
		boolean result = true;

		if (inputArray.length < 3) {
			result = true;
		} else {
			for (int i=0; i<=inputArray.length-3; i++) {
				String first = inputArray[i];
				String middle = inputArray[i+1];
				String last = inputArray[i+2];

				if ((first.equals(middle) && middle.equals(last)) && (first.equals(value1) || first.equals(value2))) {
					result = false;	// found 3-in-a-row triplet of the same value.
					break;
				}
			}
		}
		return result;
	}

	/*
	 *	Checks if array contains the same number of two values and each value half-fills the array.
	 *	Returns true if satisfies, false otherwise.
	 */
	public static boolean equalityCheck(int[] inputArray, int value1, int value2) {
		int num1 = 0;
		int num2 = 0;

		for (int value : inputArray) {
			if (value==value1) num1++;
			else if (value==value2) num2++;
		}

		boolean result;
		if (num1==num2 && num2>0 && num2==(int)(inputArray.length*0.5)) {
			result = true;
		} else {
			result = false;
		}

		return result;
	}

	public static boolean equalityCheck(String[] inputArray, String value1, String value2) {
		int num1 = 0;
		int num2 = 0;

		for (String value : inputArray) {
			if (value.equals(value1)) num1++;
			else if (value.equals(value2)) num2++;
		}

		boolean result;
		if (num1==num2 && num2>0 && num2==(int)(inputArray.length*0.5)) {
			result = true;
		} else {
			result = false;
		}

		return result;
	}

	/*
	 *	Returns the number of occurences of a value in the given array.
	 */
	public static int numOfOccurrences(int[] inputArray, int value) {
		int num = 0;

		for (int val : inputArray) {
			if (val==value) num++;
		}

		return num;
	}

	public static int numOfOccurrences(String[] inputArray, String value) {
		int num = 0;

		for (String val : inputArray) {
			if (value.equals(val)) num++;
		}

		return num;
	}

	/*
	 * Returns the number of givens in a puzzle.
	 */
	public static int numOfKnownCells(int[][] grid, int value1, int value2) {
		int num = 0;
		for (int row=0; row<grid.length; row++) {
			for (int col=0; col<grid[row].length; col++) {
				int val = grid[row][col];
				if ((val==value1) || (val==value2)) num++;
			}
		}
		
		return num;
	}

	public static int numOfKnownCells(String[][] grid, String value1, String value2) {
		int num = 0;
		for (int row=0; row<grid.length; row++) {
			for (int col=0; col<grid[row].length; col++) {
				String val = grid[row][col];
				if ((val.equals(value1)) || (val.equals(value2))) num++;
			}
		}

		return num;
	}

	/*
	 *	Checks if the given array list contains same elements.
	 *	Used for detecting repeated results in result list.
	 */
	public static boolean repeatIntArraysCheck(ArrayList<int[][]> arrayList) {
		boolean repeat = false;

		System.out.println("Checking for repeat elements in array list...");

		for (int i=(arrayList.size()-1); i>0; i--) {
			for (int j=i-1; j>=0; j--) {
				int[][] array1 = arrayList.get(i);
				int[][] array2 = arrayList.get(j);

				boolean same = Arrays.deepEquals(array1, array2);

				if (same) {
					repeat = true;
					System.out.printf("Repeat detected between element %d and element %d.\n", i, j);
					break;
				}
			}

			if (repeat) break;
		}

		String result = (repeat)? "Fail" : "Pass";
		System.out.println("Repeat elements checking done. Result: " + result);

		return repeat;
	}

	public static boolean repeatStringArraysCheck(ArrayList<String[][]> arrayList) {
		boolean repeat = false;

		System.out.println("Checking for repeat elements in array list...");

		for (int i=(arrayList.size()-1); i>0; i--) {
			for (int j=i-1; j>=0; j--) {
				String[][] array1 = arrayList.get(i);
				String[][] array2 = arrayList.get(j);

				boolean same = Arrays.deepEquals(array1, array2);

				if (same) {
					repeat = true;
					System.out.printf("Repeat detected between element %d and element %d.\n", i, j);
					break;
				}
			}

			if (repeat) break;
		}

		String result = (repeat)? "Fail" : "Pass";
		System.out.println("Repeat elements checking done. Result: " + result);

		return repeat;
	}

	public static boolean repeatStringCheck(ArrayList<String> arrayList) {
		boolean repeat = false;

		System.out.println("Checking for repeat String in ArrayList...");

		for (int i=(arrayList.size()-1); i>0; i--) {
			for (int j=i-1; j>=0; j--) {
				String str1 = arrayList.get(i);
				String str2 = arrayList.get(j);

				boolean same = str1.equals(str2);

				if (same) {
					repeat = true;
					System.out.printf("Repeat detected between String %d and String %d.\n", i, j);
					break;
				}
			}

			if (repeat) break;
		}

		String result = (repeat)? "Fail" : "Pass";
		System.out.println("Repeat String checking done. Result: " + result);

		return repeat;
	}

	public static boolean repeatPuzzleCheck(ArrayList<Puzzle> arrayList) {
		boolean repeat = false;

		System.out.println("Checking for repeat Puzzle in ArrayList...");

		for (int i=(arrayList.size()-1); i>0; i--) {
			for (int j=i-1; j>=0; j--) {
				String str1 = arrayList.get(i).puzzle;
				String str2 = arrayList.get(j).puzzle;

				boolean same = str1.equals(str2);

				if (same) {
					repeat = true;
					System.out.printf("Repeat detected between Puzzle %d and Puzzle %d.\n", i, j);
					break;
				}
			}

			if (repeat) break;
		}

		String result = (repeat)? "Fail" : "Pass";
		System.out.println("Repeat Puzzle checking done. Result: " + result);

		return repeat;
	}
}




