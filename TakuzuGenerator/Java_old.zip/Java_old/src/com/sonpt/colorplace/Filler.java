/*************************************************************************
 *  File:   Filler.java
 *  Class:  Filler
 *
 *  Starts with empty grid, fills in values until to form a valid grid.
 *
 *************************************************************************/
package com.sonpt.colorplace;

import java.util.*;

public class Filler {

    private static final boolean ANALYZE_MODE = false;

    public static long totalTrials = 0;
    public static long failedTrials = 0;

    public static int currentFinishedRow = -1;  // used to inform how much of the grid was constructed.

    //constructor
    public Filler() {

    }

    /*
     *  Generates numOfGrids valid grids of size x size that satisfies 2 game rules.
     *  The function stops when one of the following happens: 
     *      - The desired number of grids has been created.
     *      - The maximum number of attempts was met.
     *      - formGrid() has run to exhausted (tried all possibilities).
     *  Parameters:
     *      (int) size          size of grids to be generated
     *      (int) value1        one of the two values of the game
     *      (int) value2        one of the two values of the game
     *      (int) numOfGrids    number of grids to generate, -1 means all possible grids, 0 is illegal
     *      (int) maxAttempts   maximum number of attempts allowed, -1 means no limit, 0 is illegal
     *      (long) maxTrialsPerAttempt    maximum number of trials allowed in one form grid session, -1 means no limit
     *      (ArrayList<String>) excludeList    discard generated grids that replicates any one in this list
     *
     *  Return:
     *      (ArrayList<String>) the list of generated grids in form of 2-dimensional array of int.
     */
    public static ArrayList<String> formValidGrids(int size, int value1, int value2, int numOfGrids, int maxAttempts, long maxTrialsPerAttempt, ArrayList<String> excludeList) {   
        
        // Arguments checking...
        if ((maxAttempts==0) || (numOfGrids==0)) {
            throw new IllegalArgumentException();
        }

        // Measure runtime.
        long startTime = System.currentTimeMillis();

        int[] lineIndices = new int[size];   // array contains index numbers in a line: 1,2,3,4,etc.
        for (int i=0; i<lineIndices.length; i++) {
            lineIndices[i] = i;
        }

        // First find list of valid lines, valid lines are arrays containing occurrences of
        // value1, value2 so that the 2 rules of the game are satisfied.
        ArrayList<int[]> validLines = findValidLines(lineIndices, value1, value2);
        
        ArrayList<String> listOfGrids = new ArrayList<String>();  // list of generated grids.
        int[][] grid = new int[size][size];     // placeholding grid used for construction and validation.

        System.out.println("Generating grids...");
        
        // Form grids by adding rows one-by-one. This process will be repeated until one of the following happens:
        //  - The desired number of grids has been created.
        //  - The maximum number of attempts was met.
        //  - formGrid() has run to exhausted (tried all possibilities).
        int attempts = 0;
        boolean exhausted = false, reachedMaxAttempts = false, createdEnoughGrids = false;
        do {
            System.out.printf("Current attempt: %d; Grids created: %d\n", attempts+1, listOfGrids.size());

            // Reset stats.
            totalTrials = 0;
            failedTrials = 0;
            currentFinishedRow = -1;

            // Try forming a new grid and determine terminating conditions.
            exhausted = exhausted || !formGrid(validLines, size, value1, value2, 0, grid, listOfGrids, maxTrialsPerAttempt, excludeList);
            reachedMaxAttempts = (++attempts==maxAttempts);
            createdEnoughGrids = (listOfGrids.size()==numOfGrids);

        } while(!exhausted && !reachedMaxAttempts && !createdEnoughGrids);
        
        // Display runtime.
        long stopTime = System.currentTimeMillis();
        long elapsedTime = stopTime - startTime;
        String runtime = Helper.formatTime(elapsedTime);

        System.out.println("===========================================================");
        System.out.println("Finished generating valid grids. Results:");
        System.out.printf("\nGrids required:\t\t%d (size %dx%d)", numOfGrids, size, size);
        System.out.printf("\nGrids constructed:\t%d (%.0f%% requirement)", listOfGrids.size(), (float)listOfGrids.size()*100/numOfGrids);
        System.out.printf("\nMax attempts allowed:\t%d", maxAttempts);
        System.out.printf("\nAttempts:\t\t%d", attempts);
        System.out.printf("\nMax trials per attempt:\t%d", maxTrialsPerAttempt);
        System.out.printf("\nLast totalTrials:\t%d", totalTrials);
        System.out.printf("\nLast failedTrials:\t%d (%.2f%%)", failedTrials, (float)failedTrials*100/totalTrials);
        System.out.printf("\nTime:\t\t\t%s", runtime);
        System.out.println("\n===========================================================");

        return listOfGrids;
    }

    /*
     *  Form valid grids by adding rows taken from the list of validLines one-by-one to an empty grid.
     *  Validating is performed while adding row to make sure that the formed grid satisfies 2 game rules.
     */
    public static boolean formGrid(ArrayList<int[]> validLines, int size, int value1, int value2, int startRow, int[][] grid, ArrayList<String> listOfGrids, long maxTrialsPerAttempt, ArrayList<String> excludeList) {
        boolean finish = false;

        if (startRow==size) {
            // Grid was successfully constructed!
            // But we still need to check if the current grid replicates another formerly added to the list.
            // And we also need to make sure that it is not in the exclude list either!
            String gridStr = Helper.puzzleIntGridToString(grid);    // convert the int grid to a string for comparison.
            
            boolean repeat = false;
            for (String g : listOfGrids) {
                repeat = gridStr.equals(g);
                if (repeat) break;
            }

            if (!repeat) {
                for (String eg : excludeList) {
                    repeat = gridStr.equals(eg);
                    if (repeat) break;
                }
            }

            if (!repeat) {
                // Add the new grid to the list.
                // Note that we use Arrays.copyOf() instead of Helper.deepCopyOfGrid() to
                // save memory. deepCopyOfGrid() will create an actual new 2D array ("data" array) and return
                // a "array reference" to that data array.
                //      listOfGrids-->array reference-->new data array (memory occupying).
                // While what we're doing here with Arrays.copyOf() is to create a new "array reference"
                // that point to arrays in validLines, so all data already stored in validLines and
                // it serves as a "data" center, no new "data array" is created.
                //      listOfGrids-->array reference-->arrays in validLines.
                // listOfGrids.add(Arrays.copyOf(grid, grid.length)); 

                listOfGrids.add(gridStr);
                
                finish = true;  // Job done!

                if (ANALYZE_MODE) System.out.printf("\nGenerated grid number: %d\n", listOfGrids.size());

            } else {
                if (ANALYZE_MODE) {
                    System.out.println("Discarded repeated grid.\n");
                }
            }

        } else {
            // Add new row the grid.
            // First create a shuffle list of validLines indices.
            int[] shuffleIndices = Helper.createShuffleList(validLines.size());

            for (int i=0; i<shuffleIndices.length; i++) {
                
                // Stop if maximum allowed number of trials has been reached.
                if (totalTrials==maxTrialsPerAttempt) {
                    finish = true;
                    break;
                }

                // Otherwise continue working.
                int index = shuffleIndices[i];

                // Assign the current row with a line from validLines list at a shuffled index.
                // Note that we can do this without affecting copys of grid (those we add to
                // listOfGrids) cause we're effective set grid[startRow] to point to another
                // array, while the corresponding [startRow] of copy arrays still point to the
                // old array. In other words, as long as validLines remains unchanged, then the
                // copys added to listOfGrids won't be altered.
                // But if we do something like grid[startRow][someCol] = newValue; then it will
                // alter the corresponding element in validLines, and in turn alter the copys in
                // listOfGrids since those copys reference that element of validLines.
                //
                // Also note that we don't need to create a copy of grid and work on it since we
                // only check for the part contains row [0] to row [startRow] so the previously added row
                // from [startRow+1] onward don't matter.
                grid[startRow] = validLines.get(index);

                totalTrials++;   // count the number of totalTrials for analysis purpose.

                // Display progress.
                if (maxTrialsPerAttempt<=0) {
                    String progress = (totalTrials%2==0)? ".   \r" : "..  \r"; // spaces to clear garbage from previous print command.
                    System.out.printf(progress);
                } else {
                    float percent = (float)totalTrials*100/maxTrialsPerAttempt;
                    System.out.printf("Current attempt progress: %.0f %%  \r", percent);
                }

                // Check if the so-far grid statisfies 2 game rules.
                // Only need to check columns since rows already valid.
                boolean satisfied = true;
                if (startRow>=2) {
                    for (int col=0; col<size; col++) {
                        // Optimization stategy: perform early error-detecting by breaking 
                        // validating process into small steps. If any step fails, we'll end 
                        // the process immediately with a fail test result without spending more
                        // time testing the current row.

                        // 1st step: detect 3-in-a-row triplet. Triplet consists of the last three cells
                        // of the column that contains the cell belonging to the newly added row.
                        int first = grid[startRow-2][col];
                        int middle = grid[startRow-1][col];
                        int last = grid[startRow][col];

                        if ((first==middle) && (middle==last)) {
                            satisfied = false; // 3-in-a-row detected.
                            break;
                        }

                        // 2nd step: check if any value exceeds its maximum allowed occurrences (size/2).
                        // Effectively that is checking if num1 or num2 > size/2.
                        // This will also make sure that num1=num2=size/2 when the grid is fully filled.
                        int num1=0, num2=0;
                        for (int r=0; r<=startRow; r++) {
                            int val = grid[r][col];
                            if (val==value1) num1++;
                            else num2++;
                        }
                        
                        if ((num1 > (size/2)) || (num2 > (size/2))) {
                            satisfied = false;
                            break;
                        }
                    }       
                }

                // If all columns satisfy the 2 rules, continue adding the next row.
                // It not, repeat for loop with the next line from validLines.
                if (satisfied) {
                    // if (ANALYZE_MODE) {
                    //     if (startRow > currentFinishedRow) {
                    //         currentFinishedRow = startRow;
                    //         System.out.println("Finished row number " + currentFinishedRow);
                    //     } else {
                    //         System.out.println("Replaced row number " + startRow);
                    //     }
                    // }
                    
                    int nextRow = startRow + 1;
                    finish = formGrid(validLines, size, value1, value2, nextRow, grid, listOfGrids, maxTrialsPerAttempt, excludeList);
                    if (finish) break;    // stop the process when finished.
                } else {
                    failedTrials++;    // count the number of failed trials for analysis.
                }
            }
        }

        return finish;
    }

    public static ArrayList<int[]> findValidLines(int[] lineIndices, int value1, int value2) {
        int lineSize = lineIndices.length;
        int halfSize = (int) (lineSize*0.5);

        ArrayList<int[]> validLines = new ArrayList<int[]>();   // list contains all the valid lines found.

        // First find all possible combinations of halfSize indices where we can fill
        // with one value (either value1 or value2), that means we fill half the line
        // with one value and only need to fill the other half with the other value 
        // and we can form a full line with equal number of value1 and value2.
        ArrayList<int[]> combinations = Helper.findCombinations(lineIndices, halfSize);

        // Now construct lines with equal number of value1 and value2.
        for (int[] indices : combinations) {
            int[] line = new int[lineSize];
            // List ids = Arrays.asList(indices);
            for (int i=0; i<line.length; i++) {
                // Fill all the line positions with index presented in the indices combination
                // with values1, and other indices with value2.
                if (Helper.arrayContains(indices, i)) {
                    line[i] = value1;
                } else {
                    line[i] = value2;
                }
            }
            validLines.add(line);
        }

        int equalizedLinesNum = validLines.size();

        // Finally check each line for 3-in-a-row triplets and equality (redundant),
        // and remove those unsatisfied, then we have a list of all satisfied lines.
        // The following method shows you how to use an Iterator to filter an arbitrary 
        // Collection — that is, traverse the collection removing specific elements.
        // (http://docs.oracle.com/javase/tutorial/collections/interfaces/collection.html)
        for (Iterator<int[]> it = validLines.iterator(); it.hasNext(); ) {
            int[] line = it.next();
            boolean satisfied = Validator.validateLine(line, value1, value2);

            if (!satisfied) {
                it.remove();    
            }
        }

        int validLinesNum = validLines.size();    
        int linePossibilities = (int)(Math.pow(2, lineSize));
        double oneLineValidPercent = (double)validLinesNum/linePossibilities;
        double allLinesValidPercent = Math.pow(oneLineValidPercent, lineSize);
        double numOfPuzzleWithValidRows = Math.pow(validLinesNum,lineSize);
        double numOfValidPuzzle = (numOfPuzzleWithValidRows*allLinesValidPercent);

        if (ANALYZE_MODE) {
            System.out.println("===========================================================");
            System.out.println("Filler statistics:");
            System.out.printf("\nLine size:\t\t\t%d", lineSize);
            System.out.printf("\nPossible lines:\t\t\t%d", linePossibilities);
            System.out.printf("\nEqualized lines:\t\t%d", equalizedLinesNum);
            System.out.printf("\nValid lines:\t\t\t%d", validLinesNum);
            System.out.printf("\noneLineValidPercent:\t\t%.10f", oneLineValidPercent);
            System.out.printf("\nallLinesValidPercent:\t\t%.10f", allLinesValidPercent);
            System.out.printf("\nnumOfPuzzleWithValidRows:\t%.0f", numOfPuzzleWithValidRows);
            System.out.printf("\nnumOfValidPuzzle:\t\t%.0f", numOfValidPuzzle);
            System.out.println("\n===========================================================");
        }

        return validLines;
    }
}