/*************************************************************************
 *  File:	Puzzle.java
 *	Class: 	Puzzle
 *
 *
 *************************************************************************/
package com.sonpt.colorplace;

public class Puzzle {
	public final int size;
	public final String puzzle;
	public final String solution;
	public final int givenNum;
	public final int parseNum;
	public final float parsePercent;
	public final int lsdNum;
	public final float lsdPercent;
	public final int alsdNum;
	public final float alsdPercent;
	public final String level;

	// Constructor
	public Puzzle(int sz, String p, String s, int gn, int pn, float pp, int lsdn, float lsdp, int alsdn, float alsdp, String l) {
		size = sz;
		puzzle = p;
		solution = s;
		givenNum = gn;
		parseNum = pn;
		parsePercent = pp;
		lsdNum = lsdn;
		lsdPercent = lsdp;
		alsdNum = alsdn;
		alsdPercent = alsdp;
		level = l;
	}
}