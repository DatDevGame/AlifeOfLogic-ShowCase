/*************************************************************************
 *  File:	PackData.java
 *	Class: 	PackData
 *
 *  Database class, instantiates pack database and provides read/write methods.
 *
 *************************************************************************/
package com.sonpt.colorplace;

import java.sql.*;
import java.util.*;

public class PackData {

	private static final String INFO_TABLE = "info";
    private static final String PUZZLE_TABLE = "puzzles";
    private static final String[] infoNames = {"Sizes", "Levels", "Puzzles"};

	/*
     *  Initializes the pack database and connects to it.
     *  Creates the designated tables: info table and puzzle table.
     *  Returns the connection to the database.
     */
    public static Connection initPack(String dbFile) throws ClassNotFoundException {
        // Load the sqlite-JDBC driver using the current class loader.
        // This is the reason why we have to throw ClassNotFoundException above.
        Class.forName("org.sqlite.JDBC");

        Statement statement = null;
        Connection connection = null;

        try {
            // Create a database connection
            String url = "jdbc:sqlite:" + dbFile;
            connection = DriverManager.getConnection(url);

            statement = connection.createStatement();
            statement.setQueryTimeout(30);  // set timeout to 30 sec.

            // Create the designated tables of the pack database.
            // Create table to hold the pack's general information.
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS " + INFO_TABLE + " (name TEXT, value TEXT);");

            // Create to hold generated puzzles.
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS " + PUZZLE_TABLE + 
            	" (id INTEGER PRIMARY KEY, pack TEXT, pNumber INTEGER, p TEXT, s TEXT, sz INTEGER, gn INTEGER, pn INTEGER, pp FLOAT, lsdn INTEGER, lsdp FLOAT, alsdn INTEGER, alsdp FLOAT, l TEXT);");    

        } catch (SQLException e) {
            // if the error message is "out of memory", 
            // it probably means no database file is found
            System.err.println(e.getMessage());

        } finally {
            try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
        }

        return connection;
    }

    /*
     *  Updates the info table of the pack.
     */
    public static void updatePackInfo(Connection connection) {
    	Statement statement = null;

    	// Get the updated information pieces from the pack.
    	// The total number of puzzles.
    	String puzzleCount = Integer.toString(getPuzzlesNumber(connection));

    	// List of levels included.
    	String includedLevels = "";
    	for (Common.Level level : Common.Level.values()) {
            int count = getPuzzlesNumber(connection, level);
            if (count>0) {
            	// Construct a list of level codes with comma separated.
            	if (includedLevels.length()==0) {includedLevels += level.getCode();}
            	else {includedLevels += "," + level.getCode();}
            }
        }

        // List of sizes included.
        String includedSizes = "";
        for (Common.Size size : Common.Size.values()) {
        	int count = getPuzzlesNumber(connection, size);
        	if (count>0) {
        		// Construct a list of size codes with comma separated.
        		if (includedSizes.length()==0) {includedSizes += size.getCode();}
        		else {includedSizes += "," + size.getCode();}
        	}
        }

        try {
            statement = connection.createStatement();
            statement.setQueryTimeout(30);  // set timeout to 30 sec.

            for (String name : infoNames) {
            	String delete = "DELETE FROM " + INFO_TABLE + " WHERE name='" + name + "'";
            	statement.executeUpdate(delete);

            	String value = null;
            	if (name == "Levels") {value = includedLevels;}
            	else if (name == "Sizes") {value = includedSizes;}
            	else if (name == "Puzzles") {value = puzzleCount;}

            	String insert = "INSERT INTO " + INFO_TABLE + " VALUES ('" + name + "', '" + value + "')";
            	statement.executeUpdate(insert);
	    	}

        } catch (SQLException e) { 
            System.err.println(e.getMessage()); 
        } finally {
            try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
        }
    }

    /*
     *  Inserts a new puzzle into the pack.
     */
    public static void insertPuzzleToPack(Connection connection, String pack, int pNumber, Puzzle puzzle) {
        Statement statement = null;

        try {
            statement = connection.createStatement();
            statement.setQueryTimeout(30);  // set timeout to 30 sec.

            String query = "INSERT INTO " + PUZZLE_TABLE + " VALUES (NULL, " + 
            												"'" + pack + "', " +
            												pNumber + ", " + 
            												"'" + puzzle.puzzle + "', " +
            												"'" + puzzle.solution + "', " +
            												puzzle.size + ", " + 
            												puzzle.givenNum + ", " +
            												puzzle.parseNum + ", " +
            												puzzle.parsePercent + ", " +
            												puzzle.lsdNum + ", " +
            												puzzle.lsdPercent + ", " +
            												puzzle.alsdNum + ", " +
            												puzzle.alsdPercent + ", " +
            												"'" + puzzle.level + "')";
            statement.executeUpdate(query);
            
        } catch (SQLException e) { 
            System.err.println(e.getMessage()); 
        } finally {
            try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
        }
    }

    /*
     *  Removes a puzzle at the specified id from the pack.
     */
    public static void removePuzzleFromPack(Connection connection, int id) {
        Statement statement = null;

        try {
            statement = connection.createStatement();
            statement.setQueryTimeout(30);  // set timeout to 30 sec.

            String query = "DELETE FROM " + PUZZLE_TABLE + " WHERE id=" + id;
            statement.executeUpdate(query);
            
        } catch (SQLException e) { 
            System.err.println(e.getMessage()); 
        } finally {
            try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
        }
    }

    public static void removePuzzleFromPack(Connection connection, Puzzle puzzle) {
        Statement statement = null;

        try {
            statement = connection.createStatement();
            statement.setQueryTimeout(30);  // set timeout to 30 sec.

            String query = "DELETE FROM " + PUZZLE_TABLE + " WHERE p='" + puzzle.puzzle + "'";
            statement.executeUpdate(query);
            
        } catch (SQLException e) { 
            System.err.println(e.getMessage()); 
        } finally {
            try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
        }
    }

    public static void removePuzzleFromPack(Connection connection, String puzzleStr) {
        Statement statement = null;

        try {
            statement = connection.createStatement();
            statement.setQueryTimeout(30);  // set timeout to 30 sec.

            String query = "DELETE FROM " + PUZZLE_TABLE + " WHERE p='" + puzzleStr + "'";
            statement.executeUpdate(query);
            
        } catch (SQLException e) { 
            System.err.println(e.getMessage()); 
        } finally {
            try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
        }
    }

    /*
     *	Returns the all the puzzles in the list.
     */
    public static ArrayList<Puzzle> getPuzzles(Connection connection) {
		Statement statement = null;
		ResultSet rs = null;
		ArrayList<Puzzle> puzzles = new ArrayList<Puzzle>();

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String query = "SELECT * FROM " + PUZZLE_TABLE;
			rs = statement.executeQuery(query);

			while (rs.next()) {
				int sz = rs.getInt("sz");
				String p = rs.getString("p");
				String s = rs.getString("s"); 	
				int gn = rs.getInt("gn");		
				int pn = rs.getInt("pn");
				float pp = rs.getFloat("pp");
				int lsdn = rs.getInt("lsdn");
				float lsdp = rs.getFloat("lsdp");
				int alsdn = rs.getInt("alsdn");
				float alsdp = rs.getFloat("alsdp");
				String l = rs.getString("l");

				Puzzle puzzle = new Puzzle(sz, p, s, gn, pn, pp, lsdn, lsdp, alsdn, alsdp, l);
				puzzles.add(puzzle);
			}

		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { System.err.println(e); };
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }

		return puzzles;
	}

	/*
     *	Returns the all the puzzles of the specified size in the list.
     */
    public static ArrayList<Puzzle> getPuzzles(Connection connection, Common.Size size) {
		Statement statement = null;
		ResultSet rs = null;
		ArrayList<Puzzle> puzzles = new ArrayList<Puzzle>();

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String query = "SELECT * FROM " + PUZZLE_TABLE + " WHERE sz=" + size.getCode();
			rs = statement.executeQuery(query);

			while (rs.next()) {
				int sz = rs.getInt("sz");
				String p = rs.getString("p");
				String s = rs.getString("s"); 	
				int gn = rs.getInt("gn");		
				int pn = rs.getInt("pn");
				float pp = rs.getFloat("pp");
				int lsdn = rs.getInt("lsdn");
				float lsdp = rs.getFloat("lsdp");
				int alsdn = rs.getInt("alsdn");
				float alsdp = rs.getFloat("alsdp");
				String l = rs.getString("l");

				Puzzle puzzle = new Puzzle(sz, p, s, gn, pn, pp, lsdn, lsdp, alsdn, alsdp, l);
				puzzles.add(puzzle);
			}

		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { System.err.println(e); };
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }

		return puzzles;
	}

	/*
     *	Returns the all the puzzles of the specified level in the list.
     */
    public static ArrayList<Puzzle> getPuzzles(Connection connection, Common.Level level) {
		Statement statement = null;
		ResultSet rs = null;
		ArrayList<Puzzle> puzzles = new ArrayList<Puzzle>();

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String query = "SELECT * FROM " + PUZZLE_TABLE + " WHERE l='" + level.getCode() + "';";
			rs = statement.executeQuery(query);

			while (rs.next()) {
				int sz = rs.getInt("sz");
				String p = rs.getString("p");
				String s = rs.getString("s"); 	
				int gn = rs.getInt("gn");		
				int pn = rs.getInt("pn");
				float pp = rs.getFloat("pp");
				int lsdn = rs.getInt("lsdn");
				float lsdp = rs.getFloat("lsdp");
				int alsdn = rs.getInt("alsdn");
				float alsdp = rs.getFloat("alsdp");
				String l = rs.getString("l");

				Puzzle puzzle = new Puzzle(sz, p, s, gn, pn, pp, lsdn, lsdp, alsdn, alsdp, l);
				puzzles.add(puzzle);
			}

		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { System.err.println(e); };
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }

		return puzzles;
	}

	/*
     *	Returns the all the puzzles of the specified size & level in the list.
     */
    public static ArrayList<Puzzle> getPuzzles(Connection connection, Common.Size size, Common.Level level) {
		Statement statement = null;
		ResultSet rs = null;
		ArrayList<Puzzle> puzzles = new ArrayList<Puzzle>();

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String query = "SELECT * FROM " + PUZZLE_TABLE + " WHERE sz=" + size.getCode() + " AND l='" + level.getCode() + "';";
			rs = statement.executeQuery(query);

			while (rs.next()) {
				int sz = rs.getInt("sz");
				String p = rs.getString("p");
				String s = rs.getString("s"); 	
				int gn = rs.getInt("gn");		
				int pn = rs.getInt("pn");
				float pp = rs.getFloat("pp");
				int lsdn = rs.getInt("lsdn");
				float lsdp = rs.getFloat("lsdp");
				int alsdn = rs.getInt("alsdn");
				float alsdp = rs.getFloat("alsdp");
				String l = rs.getString("l");

				Puzzle puzzle = new Puzzle(sz, p, s, gn, pn, pp, lsdn, lsdp, alsdn, alsdp, l);
				puzzles.add(puzzle);
			}

		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { System.err.println(e); };
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }

		return puzzles;
	}

	/*
     *	Returns the puzzle at the specified id.
     */
    public static Puzzle getPuzzle(Connection connection, int id) {
		Statement statement = null;
		ResultSet rs = null;
		Puzzle puzzle = null;

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String query = "SELECT * FROM " + PUZZLE_TABLE + " WHERE id=" + id + ";";
			rs = statement.executeQuery(query);

			while (rs.next()) {
				int sz = rs.getInt("sz");
				String p = rs.getString("p");
				String s = rs.getString("s"); 	
				int gn = rs.getInt("gn");		
				int pn = rs.getInt("pn");
				float pp = rs.getFloat("pp");
				int lsdn = rs.getInt("lsdn");
				float lsdp = rs.getFloat("lsdp");
				int alsdn = rs.getInt("alsdn");
				float alsdp = rs.getFloat("alsdp");
				String l = rs.getString("l");

				puzzle = new Puzzle(sz, p, s, gn, pn, pp, lsdn, lsdp, alsdn, alsdp, l);
			}

		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { System.err.println(e); };
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }

		return puzzle;
	}

    /*
	 *	Returns the number of puzzles in pack.
	 */
    public static int getPuzzlesNumber(Connection connection) {
		Statement statement = null;
		ResultSet rs = null;
		int count = 0;

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String query = "SELECT COUNT(*) FROM " + PUZZLE_TABLE;
			rs = statement.executeQuery(query);

			// Get the number of rows from the result set.
		    rs.next();
		    count = rs.getInt(1);
			
		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { System.err.println(e); };
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }

	    return count;
	}

	/*
	 *	Returns the number of puzzles of the specified size in pack.
	 */
    public static int getPuzzlesNumber(Connection connection, Common.Size size) {
		Statement statement = null;
		ResultSet rs = null;
		int count = 0;

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String query = "SELECT COUNT(*) FROM " + PUZZLE_TABLE + " WHERE sz=" + size.getCode();
			rs = statement.executeQuery(query);

			// Get the number of rows from the result set.
		    rs.next();
		    count = rs.getInt(1);
			
		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { System.err.println(e); };
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }

	    return count;
	}

	/*
	 *	Returns the number of puzzles of the specified level in pack.
	 */
    public static int getPuzzlesNumber(Connection connection, Common.Level level) {
		Statement statement = null;
		ResultSet rs = null;
		int count = 0;

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String query = "SELECT COUNT(*) FROM " + PUZZLE_TABLE + " WHERE l='" + level.getCode() + "';";
			rs = statement.executeQuery(query);

			// Get the number of rows from the result set.
		    rs.next();
		    count = rs.getInt(1);
			
		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { System.err.println(e); };
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }

	    return count;
	}

	/*
	 *	Returns the number of puzzles of the specified size & level in pack.
	 */
    public static int getPuzzlesNumber(Connection connection, Common.Size size, Common.Level level) {
		Statement statement = null;
		ResultSet rs = null;
		int count = 0;

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String query = "SELECT COUNT(*) FROM " + PUZZLE_TABLE + " WHERE sz=" + size.getCode() + " AND l='" + level.getCode() + "';";
			rs = statement.executeQuery(query);

			// Get the number of rows from the result set.
		    rs.next();
		    count = rs.getInt(1);
			
		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { System.err.println(e); };
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }

	    return count;
	}

    /*
     * Closes the connection to the pack database.
     */
	public static void closeDatabase(Connection connection) {
		try { if (connection != null) connection.close(); } catch (Exception e) { System.err.println(e); };
	}
}