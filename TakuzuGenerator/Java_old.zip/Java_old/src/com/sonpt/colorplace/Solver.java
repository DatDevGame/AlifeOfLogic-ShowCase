/*************************************************************************
 *  File:	Solver.java
 *	Class: 	Solver
 *
 *  Solves puzzle, also checks if multiple solutions exist.
 *
 *************************************************************************/
package com.sonpt.colorplace;

import java.util.*;

public class Solver {

	public static int numOfParsedCells = 0;
	public static int numOfParsedCellsAfterLsd = 0;
	public static int numOfParsedCellsAfterAlsd = 0;

	public static long total_trials = 0;
    public static long failed_trials = 0;

    //constructor
	public Solver() {

	}

	/*
	 *	Assigns a difficulty level to the given puzzle according to its
	 *	solving statistic and the grading criteria defined in Common class.
	 *	Parameters:
	 *		(Common.Size)	size of the puzzle
	 *		(float) parsePercent of the puzzle
	 *		(float) lsdPercent of the puzzle
	 *		(float) alsdPercent of the puzzle
	 *	Return:
	 *		(Common.Level) 	the resulted level code as define in Common.Level.
	 */
	public static Common.Level gradePuzzle(Common.Size size, float parsePercent, float lsdPercent, float alsdPercent) {
		Common.Level result = Common.Level.UNGRADED;	// default as ungraded.

		// Loop thru all the defined levels and check those corresponding to the puzzle size.
		for (Common.Level l : Common.Level.values()) {
			if (l.getSizeCode() == size.getCode()) {
	            float minPP = l.getMinParsePercent();
	            float maxPP = l.getMaxParsePercent();
	            float minLSDP = l.getMinLsdPercent();
	            float maxLSDP = l.getMaxLsdPercent();
	            float minALSDP = l.getMinAlsdPercent();
	            float maxALSDP = l.getMaxAlsdPercent();

	            boolean ppCond = (parsePercent >= minPP) && (parsePercent <= maxPP);
	            boolean lsdpCond = (lsdPercent >= minLSDP) && (lsdPercent <= maxLSDP);
	            boolean alsdCond = (alsdPercent >= minALSDP) && (alsdPercent <= maxALSDP);

	            if (ppCond && lsdpCond && alsdCond) {
	            	result = l;
	            	break;
	            }
	        }
        }

        return result;
	}

	/*
	 *	Checks if the input puzzle has only one unique solution.
	 *	Parameters:
	 *		(String[][]) puzzle the puzzle to examine.
	 *	Return:
	 *		(boolean) true if has one unique solution, false otherwise.
	 */
	public static boolean hasUniqueSolution(String[][] puzzle) {
		ArrayList<String[][]> solutions = solve(puzzle, 2, true, true, true); // look for maximum 2 solutions, LSD on, silent set to true.
		return (solutions.size()==1);
	}

	/*
	 *	Solves the input puzzle with the option of using LSD technique.
	 *	Parameters: 
	 *		(String) puzzle 		input puzzle string.
	 *		(int) numOfSolutions	number of solutions to find, -1 means all.
	 *		(boolean) useLSD 		whether to apply the LSD technique when solving.
	 *		(boolean) useALSD		whether to apply the ALSD technique when solving.
	 *		(boolean) silent 		whether to print the result to console.
	 *	Returns: 
	 *		(ArrayList<String[][]>) list of all solutions found.
	 */
	public static ArrayList<String[][]> solve(String[][] puzzle, int numOfSolutions, boolean useLSD, boolean useALSD, boolean silent) {
		// Measure runtime.
        long startTime = System.currentTimeMillis();

        // Reset stats.
        total_trials = 0;
        failed_trials = 0;
        numOfParsedCells = 0;
        numOfParsedCellsAfterLsd = 0;
        numOfParsedCellsAfterAlsd = 0;

        int size = puzzle.length;

		ArrayList<String[][]> solutions = new ArrayList<String[][]>();
		String[][] result = new String[size][size];

		if (!silent) System.out.println("Solving puzzle...");

		boolean success = parsePuzzle(puzzle, result, silent);
		if (!success) {
			if (!silent) System.out.println("Puzzle solving failed: could not parse puzzle.");
			return solutions;
		}

		if (useLSD) {
			boolean lsdSuccess = applyLsd(result, "normal", silent);
			if (!lsdSuccess) {
				if (!silent) System.out.println("Puzzle solving failed: error when applying LSD.");
				return solutions;
			}
		}

		if (useALSD) {
			boolean alsdSuccess = applyLsd(result, "advanced", silent);
			if (!alsdSuccess) {
				if (!silent) System.out.println("Puzzle solving failed: error when applying ALSD.");
				return solutions;
			}
		}

		// Finally apply search algorithm.
		search(result, solutions, numOfSolutions, silent);

		// Calculate runtime.
        long stopTime = System.currentTimeMillis();
        long elapsedTime = stopTime - startTime;
        String runtime = Helper.formatTime(elapsedTime);

		if (!silent) {
			System.out.println("===========================================================");
	        System.out.println("Finished solving puzzle. Results:");
	        System.out.printf("\nPuzzle size:\t\t\t%d x %d", size, size);
	        System.out.printf("\nSolutions required:\t\t%d", numOfSolutions);
	        System.out.printf("\nSolutions found:\t\t%d", solutions.size());
	        System.out.printf("\nnumOfParsedCells:\t\t%d (%.2f%%)", numOfParsedCells, (float)numOfParsedCells*100/(size*size));
	        System.out.printf("\nUsed LSD:\t\t\t%s", useLSD ? "Yes" : "No");
	        System.out.printf("\nnumOfParsedCellsAfterLsd:\t%d (%.2f%%)", numOfParsedCellsAfterLsd, (float)numOfParsedCellsAfterLsd*100/(size*size));
	        System.out.printf("\nUsed ALSD:\t\t\t%s", useALSD ? "Yes" : "No");
	        System.out.printf("\nnumOfParsedCellsAfterAlsd:\t%d (%.2f%%)", numOfParsedCellsAfterAlsd, (float)numOfParsedCellsAfterAlsd*100/(size*size));
	        System.out.printf("\nTotal trials:\t\t\t%d", total_trials);
	        System.out.printf("\nFailed trials:\t\t\t%d (%.2f%%)", failed_trials, (float)failed_trials*100/total_trials);
	        System.out.printf("\nTime:\t\t\t\t%s", runtime);
	        System.out.println("\n===========================================================");
		}

		return solutions;
	}

	/*
	 * 	Parse the input puzzle and construct a corresponding 2D grid, each element
	 * 	in this grid is a String of default values for that element. Then applies the given 
	 * 	values onto the grid while performing constraint propagation.
	 * 	Result is a grid of parsed puzzle where each element is a String
	 * 	represents all possible values remained for that particular element.
	 *	Returns true if no contradiction found, false otherwise.
	 */
	public static boolean parsePuzzle(String[][] puzzle, String[][] result, boolean silent) {
		boolean success = true;

		// Initialize each element of the result array with a String
		// representing all possible values for that element.
		int size = puzzle.length;

		for (int row=0; row<size; row++) {
			for (int col=0; col<size; col++) {
				result[row][col] = Common.DEFAULT_VALUE;
			}
		}

		// Now apply all the given values and perform constraint propagation
		// one the newly created array.
		int numOfGivens = 0;
		for (int row=0; row<size; row++) {
			for (int col=0; col<size; col++) {
				String val = puzzle[row][col];
				if ((val.equals(Common.VALUE_1)) || (val.equals(Common.VALUE_2))) {
					numOfGivens++;
					success = assign(result, row, col, val);
					if (!success) {
						if (!silent) System.out.println("Invalid puzzle: failed when applying givens...");
						return success;
					}
				}	
			}
		}

		numOfParsedCells = Validator.numOfKnownCells(result, Common.VALUE_1, Common.VALUE_2);

		// If we reach here, the puzzle was parsed succesfully.
		// Print out information for debug purpose.
		if (!silent) {
			System.out.printf("\n===========================================================");
			System.out.printf("\nInput puzzle size: (%d x %d)", size, size);
			System.out.printf("\nNumber of givens: %d (%.2f%%)\n", numOfGivens, (float)numOfGivens*100/(size*size));
			Helper.printGrid(puzzle);
			System.out.printf("===========================================================");
			System.out.printf("\nnumOfParsedCells: %d (%.2f%%)", numOfParsedCells, (float)numOfParsedCells*100/(size*size));
			System.out.printf("\nParsed puzzle:\n");
			Helper.printGrid(result);
			System.out.printf("===========================================================\n");
		}
		
		return success;
	}

	/*	Perform LSD technique on the given grid. More info about LSD see the doc of
	 *	the function doApplyLsdToGrid().
	 *	Return: (boolean) • true if no error occurred, regardless there's
	 *						any cell solved by LSD.
	 *					  • false if there's error while apply LSD, normally this means
	 *						the given puzzle has problem and is not solvable.
	 */
	public static boolean applyLsd(String[][] values, String technique, boolean silent) {
		assert (technique.equals("normal") || technique.equals("advanced"));

		if (!silent) System.out.println("Now applying " + technique + "-LSD technique...");

		int oldNumOfSolvedCells = Validator.numOfKnownCells(values, Common.VALUE_1, Common.VALUE_2);
		int size = values.length;
		int result = doApplyLsdToGrid(values, technique, silent);
		boolean success = (result < 0)? false : true;

		if (!success) {
			if (!silent) System.out.println("Invalid puzzle: failed when applying " + technique + "-LSD...");

		} else {
			int numOfSolvedCells = Validator.numOfKnownCells(values, Common.VALUE_1, Common.VALUE_2);

			if (technique.equals("normal")) {
				numOfParsedCellsAfterLsd = numOfSolvedCells;
			} else if (technique.equals("advanced")) {
				numOfParsedCellsAfterAlsd = numOfSolvedCells;
			}

			if (!silent) {
				System.out.printf("\n===========================================================");
		        System.out.printf("\nFinished applying %s-LSD on puzzle. Result: %s", technique, success ? "Success" : "Fail");
				System.out.printf("\nGrid after applying %s-LSD:\n", technique);
				Helper.printGrid(values);
				System.out.printf("===========================================================");
				System.out.printf("\nNumber of cells solved by %s-LSD:\t%d", technique, numOfSolvedCells - oldNumOfSolvedCells);
				System.out.printf("\nTotal cells solved after %s-LSD:\t%d (%.2f%%)", technique, numOfSolvedCells, (float)numOfSolvedCells*100/(size*size));
				System.out.printf("\n===========================================================\n");
			}
		}

		return success;
	}

	/*
	 *	Applies a solving technique called "LSD" (Last Square Deduction): if a line
	 *	has only one available slot for one value (X), and more than 2 slots for the
	 *	other value (otherwise the technique won't apply), and if applying the value X
	 *	for a certain square among the remaining empty ones leads to a contradiction
	 *	WITHIN that line, we can be sure that this particular square must have the
	 *	opposite value.
	 *	The fact that we only check for contradiction within the line makes sure that
	 *	this technique can be easily applied by human players (rather than machines),
	 *	in fact this is a common technique to solve MEDIUM puzzles. Therefore, this is
	 *	a useful measure to grade the difficulty level of the puzzle being solved.
	 *	ALSD (Advanced Last Square Deduction): a LSD technique that preceeded by a
	 *	check using a technique call "Different Two".
	 *	"Different Two": consider a group of four cells: [1 2 3 4], if 1 & 4 has
	 *	different colors, then 2 & 3 must have different color. In other words,
	 *	we can be sure that 1 cell of VALUE_1 and 1 cell of VALUE_2 are surely
	 *	assigned to cells 2 & 3, regardless of their actual order.
	 *	The combination with "Different Two" helps ALSD to apply LSD on more subtle
	 *	line configuration, hence a more advanced technique.
	 *	Inputs: (String[][]) the puzzle grid to solve
	 *			(String) 	the technique to use:
	 *						• "normal": use normal LSD
	 *						• "advanced": use Advanced LSD (ALSD) technique
	 *			(boolean) silent 	whether to print testing text to console
	 *
	 *	Return: (int) • 0: the process terminated without error, regardless there's
	 *					any cell solved by LSD.
	 *				  • -1: the process terminated with error while assigning an
	 *					LSD-dictated value to a certain cell, normally this means
	 *					the given puzzle has problem and is not solvable.
	 *				  • 1: the process is repeating itself.
	 */
	public static int doApplyLsdToGrid(String[][] values, String technique, boolean silent) {
		assert (technique.equals("normal") || technique.equals("advanced"));

		int resultCode = 0;

		// Loop thru all cells on the diagonal of the grid, examine the row and column
		// crossing at each cell to find the line has only one slot left for either value
		// and perform the LSD technique on that line.
		// Get row and column arrays of the cell.
		int size = values.length;
		String[] testValues = {Common.VALUE_1, Common.VALUE_2};

		for(int i=0; i<size; i++) {
			// Get the row i and column i and count the occurences of
			// each value within that line.
			// First examine the row number i.
			String[] rowArray = Helper.getRow(values, i);
   			int targetC = -1;
   			String failedRowValue = null;

   			for (int j=0; j<testValues.length; j++) {
   				String testValue = testValues[j];

   				if (technique.equals("normal")) {
   					targetC = applyLsdToOneLine(rowArray, testValue);
   				} else if (technique.equals("advanced")) {
   					targetC = applyAlsdToOneLine(rowArray, testValue); 	// note the use of ALSD instead of LSD
   				}
   				
   				if (targetC >= 0) {
   					failedRowValue = testValue;
   					break;
   				}
   			}
   			
			if (targetC >= 0) {
				String targetRowValue = (failedRowValue.equals(Common.VALUE_1))? Common.VALUE_2 : Common.VALUE_1;
				if (!silent) {
					System.out.println("Checking row " + (i+1));
					System.out.printf("Assigning cell %d,%d with value %s...\n", i+1, targetC+1, targetRowValue);
				}
				boolean success = assign(values, i, targetC, targetRowValue);
				
				if (success) {
					resultCode = 1;
				} else {
					resultCode = -1;
					break;
				}
			}

			// Now examine the column number i.
			// Note that the values grid may be updated now due to the row examination above.
			String[] colArray = Helper.getCol(values, i);
			int targetR = -1;
			String failedColValue = null;

			for (int k=0; k<testValues.length; k++) {
				String testValue = testValues[k];

				if (technique.equals("normal")) {
					targetR = applyLsdToOneLine(colArray, testValue);
				} else if (technique.equals("advanced")) {
					targetR = applyAlsdToOneLine(colArray, testValue); 	// note the use of ALSD instead of LSD
				}
				
				if (targetR >= 0) {
					failedColValue = testValue;
					break;
				}
			}

			if (targetR >= 0) {
				String targetColValue = (failedColValue.equals(Common.VALUE_1))? Common.VALUE_2 : Common.VALUE_1;
				if (!silent) {	
					System.out.println("Checking column " + (i+1));
					System.out.printf("Assigning cell %d,%d with value %s...\n", targetR + 1, i + 1, targetColValue);
				}
				boolean success = assign(values, targetR, i, targetColValue);

				if (success) {
					resultCode = 1;
				} else {
					resultCode = -1;
					break;
				}
			}
   		}

   		// Repeat the process if a there's at least one cell has been assigned with a new value.
		if (resultCode > 0) {
			resultCode = doApplyLsdToGrid(values, technique, silent);
		}   		

   		return resultCode;
	}

	/*
	 *	Apply LSD technique on the given row or column (in form of an array of values).
	 *	Inputs: (String[]) line 		the array of row/column values.
	 *			(String) targetValue 	the value to be tested.
	 *	Return:	(int)	• the position of the cell within the line which causes contradiction
	 *					if assigned with the given value;
	 * 					• -1 if the technique doesn't apply.
	 */
	public static int applyLsdToOneLine(String[] line, String targetValue) {
		assert (targetValue.equals(Common.VALUE_1) || targetValue.equals(Common.VALUE_2));
		
		int result = -1;
		String otherValue = (targetValue.equals(Common.VALUE_1))? Common.VALUE_2 : Common.VALUE_1;
		int occurencesOfTargetValue = Validator.numOfOccurrences(line, targetValue);
		int occurencesOfOtherValue = Validator.numOfOccurrences(line, otherValue);
		int size = line.length;

		if (((size/2 - occurencesOfTargetValue) == 1) && ((size/2 - occurencesOfOtherValue) >= 2)) {
			// If the line satisfies the requirements of the technique, keep going: try assign one of
			// the empty cell with the targetValue, and all remaining cells with the otherValue to
			// see if contradiction occurs in the line.
			// If yes, assign that cell with the otherValue.
			// If no, repeat the assigning trial with the next cell.				
			for(int c=0; c<line.length; c++) {
				if (line[c].equals(Common.DEFAULT_VALUE)) {
					// Create a copy of the being examined line and try assigning values on it.
					String[] lineCopy = Helper.deepCopyOfArray(line);
					
					lineCopy[c] = targetValue;
					for(int c2=0; c2<lineCopy.length; c2++) {
						if (lineCopy[c2].equals(Common.DEFAULT_VALUE) && (c2!=c)) {
							lineCopy[c2] = otherValue;
						}
					}

					// Now examine the filled line to see if contradiction occurred.
					// If there's contradiction, LSD has succeeded and the value of the
					// cell at position c is determined to be otherValue.
					boolean valid = Validator.validateLine(lineCopy, Common.VALUE_1, Common.VALUE_2); 	// Actually just use Validator.tripletCheck is enough.
					if (!valid) {
						result = c;
						break;
					}
				}
			}
		}

		return result;
	}

	/*
	 *	Applies ALSD (Advanced Last Square Deduction) technique on the given row or column.
	 *	Inputs: (String[]) line 		the array of row/column values.
	 *			(String) targetValue 	the value to be tested.
	 *	Return:	(int)	• the position of the cell within the line which causes contradiction
	 *					if assigned with the given value;
	 * 					• -1 if the technique doesn't apply.
	 */
	public static int applyAlsdToOneLine(String[] line, String targetValue) {
		assert (targetValue.equals(Common.VALUE_1) || targetValue.equals(Common.VALUE_2));
		
		int result = -1;
		String otherValue = (targetValue.equals(Common.VALUE_1))? Common.VALUE_2 : Common.VALUE_1;
		int occurencesOfTargetValue = Validator.numOfOccurrences(line, targetValue);
		int occurencesOfOtherValue = Validator.numOfOccurrences(line, otherValue);
		int size = line.length;

		// Search for pairs of cells that contain two different values according to "Different Two" technique.
		// We wil considered these pairs as "filled" with two different values, regardless of the actual order of their cells.
		// We will ignore these cells when filling and validating the line.
		ArrayList<Integer> excludedCells = new ArrayList<Integer>();
		for (int i=0; i<=line.length-4; i++) {
			int one, two, three, four;
			String cellOne, cellTwo, cellThree, cellFour;
			one = i; two = i+1; three = i+2; four = i+3;
			cellOne = line[one]; cellTwo = line[two]; cellThree = line[three]; cellFour = line[four];

			if (!cellOne.equals(Common.DEFAULT_VALUE) && !cellFour.equals(Common.DEFAULT_VALUE) && !cellOne.equals(cellFour)) {
				if (cellTwo.equals(cellThree) && cellTwo.equals(Common.DEFAULT_VALUE)) {
					excludedCells.add(two);
					excludedCells.add(three);
				}
			}
		}

		// Now proceed with the technique.
		// First adjust the number of occurences to reflect the pairs with determined values and were excluded.
		occurencesOfTargetValue  += excludedCells.size()/2;
		occurencesOfOtherValue += excludedCells.size()/2;

		// Now proceed as the normal LSD technique with the note that those cells in the excludedCells won't be filled and validated.
		// Also there's a an addition case when there's only one empty cell left in the line after excluding.
		if (((size/2 - occurencesOfTargetValue) == 1) && ((size/2 - occurencesOfOtherValue) >= 2)) {				
			for(int c=0; c<line.length; c++) {
				if (line[c].equals(Common.DEFAULT_VALUE) && !Helper.arrayContains(excludedCells, c)) {
					// Create a copy of the being examined line and try assigning values on it.
					String[] lineCopy = Helper.deepCopyOfArray(line);
					
					lineCopy[c] = targetValue;
					for(int c2=0; c2<lineCopy.length; c2++) {
						if (lineCopy[c2].equals(Common.DEFAULT_VALUE) && !Helper.arrayContains(excludedCells, c2) && (c2!=c)) {
							lineCopy[c2] = otherValue;
						}
					}

					// Since the line actually has some holes now, validateLine() will certainly failed,
					// but for the purpose of this test, tripletCheck is the more suitable and perfectly
					// sufficient one to use.
					boolean valid = Validator.tripletCheck(lineCopy, Common.VALUE_1, Common.VALUE_2);
					if (!valid) {
						result = c;
						break;
					}
				}
			}
		} else if (((size/2 - occurencesOfTargetValue) == 0) && ((size/2 - occurencesOfOtherValue) >= 1)) {
			// This is a special case when after excluding the line only has one slot free.
			// And if we apply the targetValue to this empty cell contradiction will occur.
			for (int p=0; p<line.length; p++) {
				if (line[p].equals(Common.DEFAULT_VALUE) && !Helper.arrayContains(excludedCells, p)) {
					result = p;
					break;
				}
			}
		}

		return result;
	}

	/*
	 *	Performs search algorithm on the parsed puzzle to find the final solution.
	 *	Returns true if no contradiction found, false otherwise.
	 */
	public static boolean search(String[][] values, ArrayList<String[][]> solutions, int numOfSolutions, boolean silent) {
		boolean finish = false;
		int size = values.length;

		// Check if the puzzle is solved.
		boolean solved = true;
		for (int row=0; row<size; row++) {
			for (int col=0; col<size; col++) {
				if (values[row][col].length()!=1) {	// or use .equals(Common.DEFAULT_VALUE) which is probably slower.
					solved = false;
					break;
				}
			}
		}

		if (solved) {
			// Add solution to the list, no need to create a copy of values 
			// since itself is a copy created in the previous step.
			solutions.add(values);

            // Done if we've found the required number of solutions.
            int num = solutions.size();
            if (!silent) System.out.println("Num of solutions found: " + num);
            if (num==numOfSolutions) {
                finish = true;
            }
		} else {
			// If not solved, do searching.
			// Search strategy: (note that a good strategy is one that can help detect contradiction as fast as possible)
			// First determine the row/column with fewest available places for one
			// particular value (in other words, find the row/column that has the most cells assigned with
			// that value) then start the search by assigning that value (we call targetValue) 
			// to a random unsolved cell in that row/column. Backtracking is performed if contradiction found.

			// Iterate through all cells on the diagonal of the values grid, examine the 
			// row and column crossing at each cell.
			int minAvailablePlaces = -1;
			int targetRow=-1, targetCol=-1;
			String targetValue="Ok Java this is initialized";

			// Loop through the grid diagonal.
			for (int i=0; i<size; i++) {
				// Check row i.
				int rowPlacesForValue1=size/2, rowPlacesForValue2=size/2;
				int rowUnsolvedCell=-1;
				for (int c=0; c<size; c++) {
					if (values[i][c].equals(Common.VALUE_1)) rowPlacesForValue1--;	// count remained places for each value in row i.
					else if (values[i][c].equals(Common.VALUE_2)) rowPlacesForValue2--;
					else rowUnsolvedCell = c;	// index of the last unsolved cell in row i.
				}

				// Check column i.
				int colPlacesForValue1=size/2, colPlacesForValue2=size/2;
				int colUnsolvedCell=-1;
				for (int r=0; r<size; r++) {
					if (values[r][i].equals(Common.VALUE_1)) colPlacesForValue1--;	// count remained places for each value in column i.
					else if (values[r][i].equals(Common.VALUE_2)) colPlacesForValue2--;
					else colUnsolvedCell = r;	// index of the last unsolved cell in column i.
				}

				// Ugly code below.
				if ((rowPlacesForValue1>0) && ((rowPlacesForValue1<minAvailablePlaces) || (minAvailablePlaces<0))) {
					minAvailablePlaces = rowPlacesForValue1;
					targetRow = i; targetCol = rowUnsolvedCell;
					targetValue = Common.VALUE_1;
				}

				if ((rowPlacesForValue2>0) && ((rowPlacesForValue2<minAvailablePlaces) || (minAvailablePlaces<0))) {
					minAvailablePlaces = rowPlacesForValue2;
					targetRow = i; targetCol = rowUnsolvedCell;
					targetValue = Common.VALUE_2;
				}

				if ((colPlacesForValue1>0) && ((colPlacesForValue1<minAvailablePlaces) || (minAvailablePlaces<0))) {
					minAvailablePlaces = colPlacesForValue1;
					targetRow = colUnsolvedCell; targetCol = i;
					targetValue = Common.VALUE_1;
				}

				if ((colPlacesForValue2>0) && ((colPlacesForValue2<minAvailablePlaces) || (minAvailablePlaces<0))) {
					minAvailablePlaces = colPlacesForValue2;
					targetRow = colUnsolvedCell; targetCol = i;
					targetValue = Common.VALUE_2;
				}
			}

			// Now try assigning targetValue to the cell at targetRow, targetCol.
			// If contradiction found, try again with the other value (backtracking).
			String otherValue = (targetValue.equals(Common.VALUE_1))? Common.VALUE_2 : Common.VALUE_1;
			String[] trialValues = {targetValue, otherValue};

			for (int j=0; j<trialValues.length; j++) {
				total_trials++;		// count number of trials for analysis.

				// Create a copy of values for trials. Note that we need to use Helper.deepCopyOfGrid() to
				// actually create a new 2D array "instance". Arrays.copyOf() won't work here since
				// values is a 2D array, and Arrays.copyOf() will only copy the reference of each "row" of 
				// values to valuesCopy, resulting in values and valuesCopy share same memory location for
				// their "rows", in other words, they point to same "row" arrays). Consequently,
				// alter valuesCopy will also affect values. Helper.deepCopyOfGrid() can solve this issue.
				String[][] valuesCopy = Helper.deepCopyOfGrid(values);
				boolean success = assign(valuesCopy, targetRow, targetCol, trialValues[j]);
				if (success) {
					finish = search(valuesCopy, solutions, numOfSolutions, silent); 	// continue searching if no contradiction found.
					if (finish) break;
				} else {
					failed_trials++;	// count number of failed trials for analysis.
				}
			}
		}
		
		return finish;
	}

	/*
	 * 	Assigns the given value to the given values array at the position specified by row and column.
	 *	Performs constraint propagation upon assigning.
	 *	Returns true if assigning succeeds, false otherwise.
	 */
	private static boolean assign(String[][] values, int row, int col, String val) {
		String otherVal = (val.equals(Common.VALUE_1))? Common.VALUE_2 : Common.VALUE_1;

		// Eliminate otherVal from cell's string.
		// To do that we need to construct a String Builder, because
		// String in Java is not mutable.
		StringBuilder sb = new StringBuilder(values[row][col]);
        int index = sb.indexOf(otherVal);

        if (index > -1) {
        	values[row][col] = sb.deleteCharAt(index).toString();
        }

       	int len = values[row][col].length();
       	if (len==0) {
       		return false;	// contradiction: removed last value.
       	}

   		// Get row and column arrays of the cell.
   		String[] rowArray = Helper.getRow(values, row);
   		String[] colArray = Helper.getCol(values, col);

   		int rowOccurrences = Validator.numOfOccurrences(rowArray, val);
   		int colOccurrences = Validator.numOfOccurrences(colArray, val);

   		if ((rowOccurrences>rowArray.length/2) || (colOccurrences>colArray.length/2)) {
   			return false;	// contradiction: exceed allowed number of occurrences of a value.
   		}

		// 1st RULE: if the number of occurrences of one value in a row/column reaches puzzleSize/2,
		// fill all unfilled cells in that row/column with the other value.
		if (rowOccurrences==rowArray.length/2) {
			for (int c=0; c<rowArray.length; c++) {
				if ((c!=col) && (rowArray[c].length()>1)) {
					boolean success = assign(values, row, c, otherVal); 	// assign other unfilled cells in the row with otherVal.
					if (!success) return false;
				}
			}
		}

		if (colOccurrences==colArray.length/2) {
			for (int r=0; r<colArray.length; r++) {
				if((r!=row) && (colArray[r].length()>1)) {
					boolean success = assign(values, r, col, otherVal); 	// assign other unfilled cells in the column with otherVal.
					if (!success) return false;
				}
			}
		}

		// 2nd RULE: if any group of 3 consecutive cells (triplet) has 2 cells of same value, 
		// then the other cell must have different value.
		ArrayList<int[][]>	triplets = Helper.getTripletsIndices(values.length, row, col);
		for (int[][] triplet : triplets) {
			boolean success = fillTriplet(values, triplet);
			if (!success) return false; 	// contradiction: 3-in-a-row detected.
		}

		// If we reach here, no contradiction found, return true.
		return true;
	}

	/*
	 *	Checks for contradiction in the given triplet (3-in-a-row cells), as well as
	 *	assigns unfilled cell if a confirmed value for that cell is deduced.
	 *	Returns true if no contradiction occurs, false otherwise.
	 */
	private static boolean fillTriplet(String[][] values, int[][] tripletIndices) {
		int firstRow = tripletIndices[0][0]; int firstCol = tripletIndices[0][1];
		int middleRow = tripletIndices[1][0]; int middleCol = tripletIndices[1][1];
		int lastRow = tripletIndices[2][0]; int lastCol = tripletIndices[2][1];

		String first = values[firstRow][firstCol];
		String middle = values[middleRow][middleCol];
		String last = values[lastRow][lastCol];

		String[] triplet = {first, middle, last};
		boolean valid = Validator.tripletCheck(triplet, Common.VALUE_1, Common.VALUE_2);

		if (!valid) {
			// System.out.printf("Contradiction: 3-in-a-row detected at row %d, column %d.", middleRow, middleCol);
			return false;
		}

		// Construct a combined string of three triplet cells' values for ease of pattern detection.
		// First replace any default values ("01") with dot "." to match with the patterns style.
		if (first.equals(Common.DEFAULT_VALUE)) first = Common.DOT;
		if (middle.equals(Common.DEFAULT_VALUE)) middle = Common.DOT;
		if (last.equals(Common.DEFAULT_VALUE)) last = Common.DOT;

		String combined = first + middle + last;

		for (String p1 : Common.CONFIRMED_PATTERNS_1) {
			if (combined.equals(p1)) {
				int row, col;
				if (first.equals(Common.DOT)) {row = firstRow; col=firstCol;}
				else if (middle.equals(Common.DOT)) {row = middleRow; col = middleCol;}
				else {row = lastRow; col = lastCol;}

				boolean success = assign(values, row, col, Common.VALUE_1);
				if (!success) return false;
			}
		}

		for (String p2 : Common.CONFIRMED_PATTERNS_2) {
			if (combined.equals(p2)) {
				int row, col;
				if (first.equals(Common.DOT)) {row = firstRow; col=firstCol;}
				else if (middle.equals(Common.DOT)) {row = middleRow; col = middleCol;}
				else {row = lastRow; col = lastCol;}

				boolean success = assign(values, row, col, Common.VALUE_2);
				if (!success) return false;
			}
		}

		// If we reach here, no contradiction found, return true.
		return true;
	}
}
