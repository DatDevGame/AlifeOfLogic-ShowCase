/*************************************************************************
 *  File:	Data.java
 *	Class: 	Data
 *
 *  Database class, instantiates puzzle database and provides read/write methods.
 *
 *************************************************************************/
package com.sonpt.colorplace;

import java.sql.*;
import java.util.*;

public class Data {

	private static Connection connection = null;
	private static final String PUZZLE_TABLE_PREFIX = "p_";
	private static final String SOLUTION_TABLE_PREFIX = "s_";

	public static Connection getConnection() {
		return connection;
	}

	public static Connection init(String dbFile) throws ClassNotFoundException {
		// Load the sqlite-JDBC driver using the current class loader.
		// This is the reason why we have to throw ClassNotFoundException above.
	    Class.forName("org.sqlite.JDBC");

	    Statement statement = null;

	    try {
			// Create a database connection
			String url = "jdbc:sqlite:" + dbFile;
			connection = DriverManager.getConnection(url);

			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			// Create tables for each puzzle size.
			for (Common.Size size : Common.Size.values()) {
				int s = size.getCode();

				// Create table to hold generated solutions.
				statement.executeUpdate("CREATE TABLE IF NOT EXISTS " + SOLUTION_TABLE_PREFIX + s + " (id INTEGER PRIMARY KEY, s TEXT);");
			
				// Create to hold generated puzzles.
				statement.executeUpdate("CREATE TABLE IF NOT EXISTS " + PUZZLE_TABLE_PREFIX + s + 
					" (id INTEGER PRIMARY KEY, sz INTEGER, p TEXT, s TEXT, gn INTEGER, pn INTEGER, pp REAL, lsdn INTEGER, lsdp REAL, alsdn INTEGER, alsdp REAL, l TEXT);");	
			}

		} catch (SQLException e) {
			// if the error message is "out of memory", 
			// it probably means no database file is found
			System.err.println(e.getMessage());

	    } finally {
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }

	    return connection;
	}

	public static int getPuzzlesNumber(Common.Size size) {
		Statement statement = null;
		ResultSet rs = null;
		int count = 0;

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String table = PUZZLE_TABLE_PREFIX + size.getCode();
			String query = "SELECT COUNT(*) FROM " + table;
			rs = statement.executeQuery(query);

			// Get the number of rows from the result set.
		    rs.next();
		    count = rs.getInt(1);
			
		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { System.err.println(e); };
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }

	    return count;
	}

	public static ArrayList<Integer> getListOfPuzzleId(Common.Size size) {
		Statement statement = null;
		ResultSet rs = null;
		ArrayList<Integer> idList = new ArrayList<Integer>();

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String table = PUZZLE_TABLE_PREFIX + size.getCode();
			String query = "SELECT id FROM " + table;
			rs = statement.executeQuery(query);

			while (rs.next()) {
				idList.add(rs.getInt("id"));
			}

		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { System.err.println(e); };
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }

		return idList;
	}

	public static ArrayList<Integer> getListOfPuzzleId(Common.Size size, Common.Level level) {
		Statement statement = null;
		ResultSet rs = null;
		ArrayList<Integer> idList = new ArrayList<Integer>();

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String table = PUZZLE_TABLE_PREFIX + size.getCode();
			String query = "SELECT id FROM " + table + " WHERE l='" + level.getCode() + "';";
			rs = statement.executeQuery(query);

			while (rs.next()) {
				idList.add(rs.getInt("id"));
			}

		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { System.err.println(e); };
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }

		return idList;
	}

	public static Puzzle getPuzzleById(Common.Size size, int id) {
		Statement statement = null;
		ResultSet rs = null;
		Puzzle puzzle = null;

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String table = PUZZLE_TABLE_PREFIX + size.getCode();
			String query = "SELECT * FROM " + table + " WHERE id=" + id;
			rs = statement.executeQuery(query);

			while (rs.next()) {
				int sz = rs.getInt("sz");
				String p = rs.getString("p");
				String s = rs.getString("s");
				int gn = rs.getInt("gn");
				int pn = rs.getInt("pn");
				float pp = rs.getFloat("pp");
				int lsdn = rs.getInt("lsdn");
				float lsdp = rs.getFloat("lsdp");
				int alsdn = rs.getInt("alsdn");
				float alsdp = rs.getFloat("alsdp");
				String l = rs.getString("l");

				puzzle = new Puzzle(sz, p, s, gn, pn, pp, lsdn, lsdp, alsdn, alsdp, l);
			}

		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { System.err.println(e); };
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }

		return puzzle;
	}

	public static ArrayList<Puzzle> getAllPuzzles(Common.Size size) {
		Statement statement = null;
		ResultSet rs = null;
		ArrayList<Puzzle> puzzles = new ArrayList<Puzzle>();

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String table = PUZZLE_TABLE_PREFIX + size.getCode();
			String query = "SELECT * FROM " + table;
			rs = statement.executeQuery(query);

			while (rs.next()) {
				int sz = rs.getInt("sz");
				String p = rs.getString("p");
				String s = rs.getString("s");
				int gn = rs.getInt("gn");
				int pn = rs.getInt("pn");
				float pp = rs.getFloat("pp");
				int lsdn = rs.getInt("lsdn");
				float lsdp = rs.getFloat("lsdp");
				int alsdn = rs.getInt("alsdn");
				float alsdp = rs.getFloat("alsdp");
				String l = rs.getString("l");

				Puzzle puzzle = new Puzzle(sz, p, s, gn, pn, pp, lsdn, lsdp, alsdn, alsdp, l);
				puzzles.add(puzzle);
			}

		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { System.err.println(e); };
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }

		return puzzles;
	}

	public static ArrayList<Puzzle> getAllPuzzles(Common.Size size, int givenNum) {
		Statement statement = null;
		ResultSet rs = null;
		ArrayList<Puzzle> puzzles = new ArrayList<Puzzle>();

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String table = PUZZLE_TABLE_PREFIX + size.getCode();
			String query = "SELECT * FROM " + table + " WHERE gn=" + givenNum;
			rs = statement.executeQuery(query);

			while (rs.next()) {
				int sz = rs.getInt("sz");
				String p = rs.getString("p");
				String s = rs.getString("s");
				int gn = rs.getInt("gn");
				int pn = rs.getInt("pn");
				float pp = rs.getFloat("pp");
				int lsdn = rs.getInt("lsdn");
				float lsdp = rs.getFloat("lsdp");
				int alsdn = rs.getInt("alsdn");
				float alsdp = rs.getFloat("alsdp");
				String l = rs.getString("l");

				Puzzle puzzle = new Puzzle(sz, p, s, gn, pn, pp, lsdn, lsdp, alsdn, alsdp, l);
				puzzles.add(puzzle);
			}

		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { System.err.println(e); };
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }

		return puzzles;
	}

	public static ArrayList<Puzzle> getPuzzlesByLevel(Common.Size size, Common.Level level) {
		Statement statement = null;
		ResultSet rs = null;
		ArrayList<Puzzle> puzzles = new ArrayList<Puzzle>();

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String table = PUZZLE_TABLE_PREFIX + size.getCode();
			String query = "SELECT * FROM " + table + " WHERE l='" + level.getCode() + "';";
			rs = statement.executeQuery(query);

			while (rs.next()) {
				int sz = rs.getInt("sz");
				String p = rs.getString("p");
				String s = rs.getString("s");
				int gn = rs.getInt("gn");
				int pn = rs.getInt("pn");
				float pp = rs.getFloat("pp");
				int lsdn = rs.getInt("lsdn");
				float lsdp = rs.getFloat("lsdp");
				int alsdn = rs.getInt("alsdn");
				float alsdp = rs.getFloat("alsdp");
				String l = rs.getString("l");

				Puzzle puzzle = new Puzzle(sz, p, s, gn, pn, pp, lsdn, lsdp, alsdn, alsdp, l);
				puzzles.add(puzzle);
			}

		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { System.err.println(e); };
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }

		return puzzles;
	}

	public static void insertPuzzles(Common.Size size, ArrayList<Puzzle> puzzles) {
		Statement statement = null;

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String table = PUZZLE_TABLE_PREFIX + size.getCode();
			for (Puzzle puzzle : puzzles) {
				int sz = puzzle.size;
				String p = puzzle.puzzle;
				String s = puzzle.solution;
				int gn = puzzle.givenNum;
				int pn = puzzle.parseNum;
				float pp = puzzle.parsePercent;
				int lsdn = puzzle.lsdNum;
				float lsdp = puzzle.lsdPercent;
				int alsdn = puzzle.alsdNum;
				float alsdp = puzzle.alsdPercent;
				String l = puzzle.level;

				String query = "INSERT INTO " + table + " VALUES (NULL, " + sz + ", '" + p + "', '" + s + "', " + gn + ", "
								+ pn + ", " + pp + ", " + lsdn + ", " + lsdp + ", " + alsdn + ", " + alsdp + ", '" + l + "')";
				statement.executeUpdate(query);
			}
			
		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }
	}

	public static void updatePuzzle(Common.Size size, int id, Puzzle newPuzzle) {
		Statement statement = null;

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String table = PUZZLE_TABLE_PREFIX + size.getCode();
			String query = "UPDATE " + table + " SET " +
							"sz=" + newPuzzle.size +
							",p='" + newPuzzle.puzzle + "'" +
							",s='" + newPuzzle.solution + "'" +
							",gn=" + newPuzzle.givenNum +
							",pn=" + newPuzzle.parseNum +
							",pp=" + newPuzzle.parsePercent +
							",lsdn=" + newPuzzle.lsdNum +
							",lsdp=" + newPuzzle.lsdPercent +
							",alsdn=" + newPuzzle.alsdNum + 
							",alsdp=" + newPuzzle.alsdPercent +
							",l='" + newPuzzle.level + "'" +
							" WHERE id=" + id + ";";
			statement.executeUpdate(query);
			
		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }
	}

	public static void deleteAllPuzzles(Common.Size size) {
		Statement statement = null;

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String table = PUZZLE_TABLE_PREFIX + size.getCode();
			String query = "DELETE * FROM " + table;
			statement.executeUpdate(query);
			
		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }
	}

	public static int getSolutionsNumber(Common.Size size) {
		Statement statement = null;
		ResultSet rs = null;
		int count = 0;

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String table = SOLUTION_TABLE_PREFIX + size.getCode();
			String query = "SELECT COUNT(*) FROM " + table;
			rs = statement.executeQuery(query);

			// Get the number of rows from the result set
		    rs.next();
		    count = rs.getInt(1);
			
		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { System.err.println(e); };
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }

	    return count;
	}

	public static String getSolutionById(Common.Size size, int id) {
		Statement statement = null;
		ResultSet rs = null;
		String solution = null;

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String table = SOLUTION_TABLE_PREFIX + size.getCode();
			String query = "SELECT * FROM " + table + " WHERE id=" + id;
			rs = statement.executeQuery(query);

			if (rs.next()) {
				solution = rs.getString("s");
			}

		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { System.err.println(e); };
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }

		return solution;
	}

	public static ArrayList<String> getAllSolutions(Common.Size size) {
		Statement statement = null;
		ResultSet rs = null;
		ArrayList<String> solutions = new ArrayList<String>();

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String table = SOLUTION_TABLE_PREFIX + size.getCode();
			String query = "SELECT * FROM " + table;
			rs = statement.executeQuery(query);

			while (rs.next()) {
				String solution = rs.getString("s");
				solutions.add(solution);
			}

		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { System.err.println(e); };
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }

		return solutions;
	}

	public static void insertSolutions(Common.Size size, ArrayList<String> solutions) {
		Statement statement = null;

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String table = SOLUTION_TABLE_PREFIX + size.getCode();
			for (String s : solutions) {
				String query = "INSERT INTO " + table + " VALUES (NULL, '" + s + "')";
				statement.executeUpdate(query);
			}
			
		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }
	}

	public static void deleteAllSolutions(Common.Size size) {
		Statement statement = null;

		try {
			statement = connection.createStatement();
			statement.setQueryTimeout(30);  // set timeout to 30 sec.

			String table = SOLUTION_TABLE_PREFIX + size.getCode();
			String query = "DELETE * FROM " + table;
			statement.executeUpdate(query);
			
		} catch (SQLException e) { 
			System.err.println(e.getMessage()); 
		} finally {
	    	try { if (statement != null) statement.close(); } catch (Exception e) { System.err.println(e); };
	    }
	}

	public static void closeDatabase() {
		try { if (connection != null) connection.close(); } catch (Exception e) { System.err.println(e); };
	}
}