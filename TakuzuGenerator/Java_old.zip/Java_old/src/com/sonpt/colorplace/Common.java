/*************************************************************************
 *  File:	Common.java
 *	Class: 	Common
 *
 *  Global constants.
 *
 *************************************************************************/
package com.sonpt.colorplace;

public class Common {

	public static final String VALUE_1 = "0";
	public static final String VALUE_2 = "1";
	public static final String DEFAULT_VALUE = VALUE_1+VALUE_2;
	public static final String DOT = ".";

	public enum Size {
		SIX(6), EIGHT(8), TEN(10), TWELVE(12), FOURTEEN(14), SIXTEEN(16), EIGHTEEN(18);

		private final int code;

		private Size(final int value) {
			code = value;
		}

		public int getCode() { return code; }
	}

	public enum LevelName {
		UNGRADED("x"),
		EASY("0"),
		MEDIUM("1"),
		HARD("2"),
		EVIL("3"),
		EVILPLUS("4");

		private final String code;

		private LevelName(final String value) {
			code = value;
		}

		public String getCode() { return code; }
	}

	public enum Level {
		// Level difficulty definition on a per size basis, including a common ungraded level.
		UNGRADED("0_x", 0, -1, -1, -1, -1, -1, -1),

		EASY_6("6_0", 6, 100, 100, 100, 100, 100, 100),
		MEDIUM_6("6_1", 6, 55, 85, 100, 100, 100, 100),
		HARD_6("6_2", 6, 0, 85, 0, 85, 65, 85),
		EVIL_6("6_3", 6, 0, 60, 0, 60, 45, 60),
		EVILPLUS_6("6_4", 6, 0, 40, 0, 40, 0, 40),

		EASY_8("8_0", 8, 100, 100, 100, 100, 100, 100),
		MEDIUM_8("8_1", 8, 70, 86, 100, 100, 100, 100),
		HARD_8("8_2", 8, 0, 88, 0, 88, 76, 88),
		EVIL_8("8_3", 8, 0, 65, 0, 65, 45, 65),
		EVILPLUS_8("8_4", 8, 0, 40, 0, 40, 0, 40),

		EASY_10("10_0", 10, 100, 100, 100, 100, 100, 100),
		MEDIUM_10("10_1", 10, 65, 87, 100, 100, 100, 100),
		HARD_10("10_2", 10, 0, 92, 0, 92, 81, 92),
		EVIL_10("10_3", 10, 0, 75, 0, 75, 55, 75),
		EVILPLUS_10("10_4", 10, 0, 50, 0, 50, 0, 50),

		EASY_12("12_0", 12, 100, 100, 100, 100, 100, 100),
		MEDIUM_12("12_1", 12, 70, 85, 100, 100, 100, 100),
		HARD_12("12_2", 12, 0, 95, 0, 95, 86, 95),
		EVIL_12("12_3", 12, 0, 80, 0, 80, 60, 80),
		EVILPLUS_12("12_4", 12, 0, 50, 0, 50, 0, 50),

		EASY_14("14_0", 14, 100, 100, 100, 100, 100, 100),
		MEDIUM_14("14_1", 14, 70, 85, 100, 100, 100, 100),
		HARD_14("14_2", 14, 0, 95, 0, 95, 86, 95),
		EVIL_14("14_3", 14, 0, 80, 0, 80, 60, 80),
		EVILPLUS_14("14_4", 14, 0, 50, 0, 50, 0, 50);

		private final String code;
		private final int sizeCode;
		private final float minParsePercent;
		private final float maxParsePercent;
		private final float minLsdPercent;
		private final float maxLsdPercent;
		private final float minAlsdPercent;
		private final float maxAlsdPercent;

		private Level(final String c, final int sz, final float minPP, final float maxPP, final float minLSDP, final float maxLSDP, final float minALSDP, final float maxALSDP) {
			code = c;
			sizeCode = sz;
			minParsePercent = minPP;
			maxParsePercent = maxPP;
			minLsdPercent = minLSDP;
			maxLsdPercent = maxLSDP;
			minAlsdPercent = minALSDP;
			maxAlsdPercent = maxALSDP;
		}

		public String getCode() { return code; }
		public int getSizeCode() { return sizeCode; }
		public float getMinParsePercent() { return minParsePercent; }
		public float getMaxParsePercent() { return maxParsePercent; }
		public float getMinLsdPercent() { return minLsdPercent; }
		public float getMaxLsdPercent() { return maxLsdPercent; }
		public float getMinAlsdPercent() { return minAlsdPercent; }
		public float getMaxAlsdPercent() { return maxAlsdPercent; }
	}

	// List of available permutations.
	// 0 0 0
	// 0 0 1
	// 0 1 0
	// 1 0 0
	// 0 1 1
	// 1 0 1
	// 1 1 0
	// 1 1 1

	public static final String[] FAILED_PATTERNS = {"000", "111"};
	// IMPORTANT!!! The order of the strings in the following two arrays are vital
	// for the program to function properly. They are to be changed.
	public static final String[] CONFIRMED_PATTERNS_1 = {".11", "1.1", "11."};
	public static final String[] CONFIRMED_PATTERNS_2 = {".00", "0.0", "00."};

    //constructor
	public Common() {
		
	}

	public static String constructLevelCode(Size sz, LevelName ln) {
		return (sz.getCode() + "_" + ln.getCode());
	}

	public static Level getLevel(Size sz, LevelName ln) {
		String levelCode = constructLevelCode(sz, ln);
		Level level = Level.UNGRADED;
		
		for (Level l : Level.values()) {
			if (levelCode.equals(l.getCode())) {
				level = l;
				break;
			}
		}

		return level;
	}
}
