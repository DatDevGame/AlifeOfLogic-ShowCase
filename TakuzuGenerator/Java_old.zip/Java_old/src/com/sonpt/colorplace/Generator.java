/*************************************************************************
 *  File:	Generator.java
 *	Class: 	Generator
 *
 *  Starts with a complete grid, removes cell values ("dig holes") to 
 *	form valid puzzles with a desired number of givens.
 *
 *************************************************************************/
package com.sonpt.colorplace;

import java.util.*;

public class Generator {

	private static final boolean ANALYZE_MODE = true;

	public static int minGivensToSolveWithoutSearch = -1;
	public static int minGivensToHaveUniqueSolution = -1;

	public static long totalDigHolesTrials = 0;
    public static long failedDigHolesTrials = 0;
    public static long totalCompensateTrials = 0;
    public static long failedCompensateTrials = 0;

    //constructor
	public Generator() {
		
	}

	/*
	 *	Removes cells from the input grid ("dig holes") to form valid puzzles with a desired
	 * 	number of givens and have a unique solution which is the input grid.
	 *
	 *	Parameters:
	 *		(String[][]) grid 	the input grid to dig holes from.
	 *
	 *		(int) numOfGivens	number of givens of the generated puzzle.
	 *
	 *		(Common.Level) 		level the required level, passing Common.Level.UNGRADED means ignore (all level accepted).
	 *
	 *		(int) numOfPuzzles	number of distinct puzzles to create, -1 means all possible puzzles can be generated with the input conditions. 0 is illegal.
	 *			Note that if we pass -1 for numOfPuzzles, we also need to pass -1 for maxTrialsPerAttempt, and a value different from -1 for maxAttempts
	 *			to enable exhausted, otherwise the program will run forever without exit point.
	 *
	 *		(ArrayList<Puzzle>) excludeList	discard generated puzzles that replicate any puzzle included in this list.
	 *
	 *		(int) maxAttempts 	maximum number of dig holes sessions to perform, terminate if reaches this limit, -1 means no limit. 0 is illegal
	 *			Pass this argument with care since it may cause the program to loop forever (especially if maxTrialsPerAttempt too small to find a valid puzzle,
	 *			not to mention that in some cases it's impossible to find the required puzzle).
	 *
	 *		(long) maxTrialsPerAttempt	stop a dig holes session if reaches this number of trials, -1 for no limit.
	 *			We set this limit to "free" the session from sinking into a "hard" route where it takes too long to found the valid puzzle.
	 *
	 *		(boolean) silent	whether or not display debug text to console
	 *	Returns:
	 *		(ArrayList<Puzzle>) array list of created puzzles.
	 */
	public static ArrayList<Puzzle> createPuzzles(String[][] grid, int numOfGivens, Common.Level level, int numOfPuzzles, ArrayList<Puzzle> excludeList, int maxAttempts, long maxTrialsPerAttempt, boolean silent) {
		
		// Argument checking...
		if ((numOfPuzzles<=-1) && (maxAttempts<=-1) && (maxTrialsPerAttempt>=0)) {
			// This combination of arguments will cause the program to loop forever.
			System.out.println("WARNING: this combination of arguments (numOfPuzzles<=-1 && maxAttempts<=-1 && maxTrialsPerAttempt>=0) will cause infinite loop.");
			throw new IllegalArgumentException();
		} else if ((maxAttempts==0) || (numOfPuzzles==0)) {
			throw new IllegalArgumentException();
		}


		// Measure runtime.
        long startTime = System.currentTimeMillis();

        // Reset stats.
        minGivensToSolveWithoutSearch = -1;
		minGivensToHaveUniqueSolution = -1;

		ArrayList<Puzzle> puzzles = new ArrayList<Puzzle>();
		String[][] puzzle = Helper.deepCopyOfGrid(grid);

		int size = grid.length;
		int numOfHoles = size*size - numOfGivens;	// number of holes to dig from the grid.

		// System.out.printf("\nGenerating %d x %d puzzles with %d givens...\n", size, size, numOfGivens);

		// Dig holes to form valid puzzles and repeat until one of the following happens:
		//	- The desired number of puzzles has been created.
		//	- The maximum number of attempts allowed was met.
		//	- The process has run to exhausted (tried all possibilites) without successful.
		//	Exhausted means it's impossible to generate a valid puzzle with the required number of givens from the input grid.
		//	Currently, we're not sure if this case applies for other grids, or maybe some
		//	of them may be possible to generate the desired puzzle from.
		
		int attempts = 0;	// number of attempt to generate puzzles, each dig holes session counts as an attempt.
		boolean success = true, reachedMaxAttempts = false, createdEnoughPuzzles = false;
		do {
			System.out.printf("Attempt #%d of %d; Puzzles created: %d        \r", attempts+1, maxAttempts, puzzles.size());

			// Reset trials counts for the new session.
			totalDigHolesTrials = 0;
	    	failedDigHolesTrials = 0;
	    	totalCompensateTrials = 0;
	    	failedCompensateTrials = 0;

	    	// Start the new dig holes session and then determine stopping conditions.
			success = success && digHoles(puzzle, grid, numOfGivens, numOfHoles, level, puzzles, maxTrialsPerAttempt, excludeList);
			reachedMaxAttempts = (++attempts==maxAttempts);
			createdEnoughPuzzles = (puzzles.size()==numOfPuzzles);

		} while(success && !reachedMaxAttempts && !createdEnoughPuzzles);

		// Calculate runtime.
        long stopTime = System.currentTimeMillis();
        long elapsedTime = stopTime - startTime;
        String runtime = Helper.formatTime(elapsedTime);

        if (!silent) {
			System.out.println("\n===========================================================");
	        System.out.println("Finished creating puzzles. Statistics:");
	        System.out.printf("\nPuzzles required:\t\t%d (size %dx%d, %d givens, level %d)", numOfPuzzles, size, size, numOfGivens, level);
	        System.out.printf("\nPuzzles created:\t\t%d", puzzles.size());
	        System.out.printf("\nMax attempts allowed:\t\t%d", maxAttempts);
	        System.out.printf("\nAttempts:\t\t\t%d", attempts);
	        System.out.printf("\nMax trials per attempt:\t\t%d", maxTrialsPerAttempt);
	        System.out.printf("\nLast totalDigHolesTrials:\t%d", totalDigHolesTrials);
	        System.out.printf("\nLast failedDigHolesTrials:\t%d (%.2f%%)", failedDigHolesTrials, (float)failedDigHolesTrials*100/totalDigHolesTrials);
	        System.out.printf("\nLast totalCompensateTrials:\t%d", totalCompensateTrials);
	        System.out.printf("\nLast failedCompensateTrials:\t%d (%.2f%%)", failedCompensateTrials, (float)failedCompensateTrials*100/totalCompensateTrials);
	        System.out.printf("\nExhausted:\t\t\t%b", !success);
	        System.out.printf("\nminGivensToHaveUniqueSolution:\t%d", minGivensToHaveUniqueSolution);
	        System.out.printf("\nminGivensToSolveWithoutSearch:\t%d", minGivensToSolveWithoutSearch);
	        System.out.printf("\nTime:\t\t\t\t%s", runtime);
	        System.out.println("\n===========================================================");
	    }

        return puzzles;
	}

	/*
	 *	Digs holes from the input grid to form valid puzzles with desired numOfHoles
	 *	and have one unique solution, which is the input grid itself.
	 * 	Parameters:
	 *		(String[][]) puzzle 	the puzzle to dig holes from
	 *		(String[][]) solution 	the reference solution of the puzzle
	 *		(int) numOfGivens 		the required number of givens of the puzzle
	 *		(int) numOfHoles 		the number of holes to dig
	 *		(Common.Level) level 	the required puzzle level
	 * 		(ArrayList<Puzzle>) puzzles 		the list to add puzzle to
	 *		(long) maxTrialsPerAttempt 			maximum number of trials allowed, terminate the process if this number is reached
	 *		(ArrayList<Puzzle>) excludeList		the list contains puzzles to exclude
	 *	Return:
	 *		(boolean) finish 	true if the process has finished, false otherwise
	 */
	private static boolean digHoles(String[][] puzzle, String[][] solution, int numOfGivens, int numOfHoles, Common.Level level, ArrayList<Puzzle> puzzles, long maxTrialsPerAttempt, ArrayList<Puzzle> excludeList) {
		boolean finish = false;

		// if (ANALYZE_MODE) System.out.println("\nDigging holes. numOfHoles: " + numOfHoles);

		if (numOfHoles==0) {

			// if (ANALYZE_MODE) {
			// 	System.out.println("Puzzle before eliminating redundancies:");
			// 	Helper.printGrid(puzzle);
			// }
			
			// Eliminate redundancies if any.
			int eliminateNum = eliminateRedundancy(puzzle);

			// if (ANALYZE_MODE) System.out.println("eliminateNum: " + eliminateNum);

			// Compensate eliminated cells and validate final puzzle. The process
			// finishes if compensate is successful.
			boolean success = compensate(puzzle, solution, numOfGivens, eliminateNum, level, puzzles, excludeList);

			if (success) finish = true;

		} else {
			// Try removing a random cell from the puzzle grid and see if it still
			// satisfies the condition of having only one unique solution.
			int size = puzzle.length;
			int[] randomPositions = Helper.createShuffleList(size*size);	// list of cell positions in a random order.
			
			for (int i=0; i<randomPositions.length; i++) {
				
				// Stop if maximum allowed number of trials for this session has been reached.
				if (totalDigHolesTrials==maxTrialsPerAttempt) {
					finish = true;
					break;
				}

				// Otherwise continue digging.	
				int position = randomPositions[i];
				int row = position/size;
				int col = position%size;

				// Remove cell value if it was not removed before.
				if (!puzzle[row][col].equals(Common.DOT)) {					
					String[][] puzzleCopy = Helper.deepCopyOfGrid(puzzle);	// create a copy of the puzzle and work on it.
					
					puzzleCopy[row][col] = Common.DOT;	// remove the value from the cell by setting it to a dot.

					// if (ANALYZE_MODE) System.out.printf("Dig hole at row %d, col %d.\n", row, col);

					totalDigHolesTrials++;

					// // Display progress.
					// if (maxTrialsPerAttempt<=0) {
					// 	String progress = (totalDigHolesTrials%2==0)? ".  \r" : ".. \r";	// spaces to clear garbage from previous print command.
					// 	System.out.printf(progress);
					// } else {
					// 	float percent = (float)totalDigHolesTrials*100/maxTrialsPerAttempt;
					// 	System.out.printf("Current attempt progress: %.0f %%  \r", percent);
					// }

					// Now check if the puzzle is still uniquely solved.
					boolean valid = Solver.hasUniqueSolution(puzzleCopy);
					if (valid) {
						// Count the number of remained givens in the current puzzle for analysis.
						// This is only applicable when running in exhausted mode.
						if (ANALYZE_MODE) {
							int remainedGivens = Validator.numOfKnownCells(puzzleCopy, Common.VALUE_1, Common.VALUE_2);
							
							if ((remainedGivens<minGivensToHaveUniqueSolution) || (minGivensToHaveUniqueSolution<0)) {
								minGivensToHaveUniqueSolution = remainedGivens;
							}
							if (Solver.numOfParsedCells==(size*size)) {
								if ((remainedGivens<minGivensToSolveWithoutSearch) || (minGivensToSolveWithoutSearch<0)) {
									minGivensToSolveWithoutSearch = remainedGivens;
								}
							}
						}

						// Puzzle has one unique solution and is valid. Continue removing.
						finish = digHoles(puzzleCopy, solution, numOfGivens, numOfHoles-1, level, puzzles, maxTrialsPerAttempt, excludeList);
						if (finish) break;

					} else {
						// if (ANALYZE_MODE) {
						// 	System.out.println("Current puzzle is invalid. Retrying...");
						// 	// Helper.printGrid(puzzleCopy);
						// }
						failedDigHolesTrials++;
					}
				}
			}
		}

		return finish;
	}

	/*
	 *	Checks for redundant given cells in the input puzzle grid. Redundant cells are those that
	 *	values can be logically deduced. Effectively detects groups of three consecutive cells
	 *	where all values are given. If found, remove value from a random cell among the three.
	 *	Parameters:
	 *		(String[][]) puzzle 	the puzzle grid to eliminate redundancy.
	 *	Return:
	 *		(int) number of redundant cells eliminated.
	 */
	private static int eliminateRedundancy(String[][] puzzle) {
		int eliminateNum = 0;	// number of eliminated redundant cells.
		int size = puzzle.length;
		Random rand = new Random();

		// Iterate through all rows and columns and examine all triplets in each of them.
		// We'll eliminate the redundant cell which is the cell whose value can be logically
		// deduced from the values of the two remained cells. For example "1" in "010", "0" in "110", etc.
		for (int i=0; i<size; i++) {
			// Check triplets in row i.
			for (int c=0; c<=size-3; c++) {
				String first = puzzle[i][c];
				String middle = puzzle[i][c+1];
				String last = puzzle[i][c+2];

				// Redundant if all three values were given. Remove the one that has different value than the other.
				if ((!first.equals(Common.DOT)) && (!middle.equals(Common.DOT)) && (!last.equals(Common.DOT))) {
					int row=-1, col=-1;
					boolean equal1 = first.equals(middle);
					boolean equal2 = middle.equals(last);

					if (!equal1 && equal2) {row = i; col=c;}	// the different cell is the first one, or...
					else if (!equal1 && !equal2) {row = i; col = c+1;}	// the middle one, or...
					else if (equal1 && !equal2) {row = i; col = c+2;}	// the last one.

					// Eliminate the different cell which is the redundant one.
					puzzle[row][col] = Common.DOT;
					eliminateNum++;

					// if (ANALYZE_MODE) System.out.printf("Eliminate cell at row %d, col %d\n", row, col);
				}
			}

			// Check triplets in column i.
			for (int r=0; r<=size-3; r++) {
				String first = puzzle[r][i];
				String middle = puzzle[r+1][i];
				String last = puzzle[r+2][i];

				// Repeat the above process for column.
				if ((!first.equals(Common.DOT)) && (!middle.equals(Common.DOT)) && (!last.equals(Common.DOT))) {
					int row=-1, col=-1;
					boolean equal1 = first.equals(middle);
					boolean equal2 = middle.equals(last);

					if (!equal1 && equal2) {row = r; col=i;}	// the different cell is the first one, or...
					else if (!equal1 && !equal2) {row = r+1; col = i;}	// the middle one, or...
					else if (equal1 && !equal2) {row = r+2; col = i;}	// the last one.

					puzzle[row][col] = Common.DOT;
					// if (ANALYZE_MODE) System.out.printf("Eliminate cell at row %d, col %d\n", row, col);
					eliminateNum++;
				}
			}
		}

		return eliminateNum;
	}

	/*
	 *	Adds compensateNum values at random cells in the puzzle with such that
	 *	won't create redundancy. The values set to those cells are the values
	 *	of corresponding cells in the solution grid.
	 *	In the end, the final puzzle will be validated for unique solution requirement,
	 *	if valid, adds it to the puzzle list and terminates the process, provided that
	 *	the puzzle doesn't repeat another puzzle formerly added to the list.
	 *	Parameters:
	 *		(String[][]) puzzle 			input puzzle grid to add cell values.
	 *		(String[][]) solution			the solution grid where values are taken to fill into the puzzle grid.
	 *		(int) numOfGivens				number of givens of the puzzle.
	 *		(int) compensateNum				number of cells to add values to.
	 *		(Common.Level) 					level the required level, passing Common.Level.UNGRADED means ignore (all level accepted).
	 *		(ArrayList<Puzzle) puzzles 	list contains generated puzzles.
	 *		(ArrayList<Puzzle) excludeList 	list contains puzzles to not replicate.
	 *	Return:
	 *		(boolean)	true if a valid puzzle is formed and added to puzzle list, false if all trials failed.
	 */
	private static boolean compensate(String[][] puzzle, String[][] solution, int numOfGivens, int compensateNum, Common.Level level, ArrayList<Puzzle> puzzles, ArrayList<Puzzle> excludeList) {
		boolean finish = false;

		// If compensateNum is 0, the puzzle is fully compensated.
		// We'll see if it is valid: has one unique solution and the percentage of
		// parsed cells falls within the required range.
		if (compensateNum==0) {
			totalCompensateTrials++;

			boolean valid = isGoodPuzzle(puzzle, level);
			if (valid) {
				// Puzzle has one unique solution and therefore is valid.
				// But we still need to check if it repeats another one formerly added to the puzzle list.
				// And we also need to make sure that it is not in the exclude list either!
				boolean repeat = false;
				String puzzleStr = Helper.puzzleStringGridToString(puzzle); 	// convert puzzle grid to string for comparison purpose.	

				for (Puzzle p : puzzles) {
					repeat = puzzleStr.equals(p.puzzle);
					if (repeat) break;
				}

				if (!repeat) {
					for (Puzzle ep : excludeList) {
	                    repeat = puzzleStr.equals(ep.puzzle);
	                    if (repeat) break;
	                }
				}

				// Create a new Puzzle instance and add it to the list if not repeated.
				if (!repeat) {

					int size = puzzle.length;
					String solutionStr = Helper.puzzleStringGridToString(solution);
					int parseNum = Solver.numOfParsedCells;
					float parsePercent = (float)parseNum*100/(size*size);
					int lsdNum = Solver.numOfParsedCellsAfterLsd;
					float lsdPercent = (float)lsdNum*100/(size*size);
					int alsdNum = Solver.numOfParsedCellsAfterAlsd;
					float alsdPercent = (float)alsdNum*100/(size*size);

					// Get the enum Size corresponding to the puzzle.
			        Common.Size enumSize = null;
			        for (Common.Size eS : Common.Size.values()) {
			            if (size == eS.getCode()) {
			                enumSize = eS;
			                break;
			            }
			        }
					Common.Level l = Solver.gradePuzzle(enumSize, parsePercent, lsdPercent, alsdPercent);
					String lc = l.getCode();

					Puzzle newPuzzle = new Puzzle(size, puzzleStr, solutionStr, numOfGivens, parseNum, parsePercent, lsdNum, lsdPercent, alsdNum, alsdPercent, lc);
					puzzles.add(newPuzzle);
					
					finish = true; 	// Our job is done!

				} else {
					if (ANALYZE_MODE) {
						System.out.println("\n*** Discarded repeated puzzle. ***\n");
					}
				}
			} 

			if(!finish) {
				// if (ANALYZE_MODE) System.out.println("Compensating completed. Puzzle is invalid. Process repeating...");
				failedCompensateTrials++;
			}

		} else {
			// More compensating to do.
			int size = puzzle.length;
			int[] randomPositions = Helper.createShuffleList(size*size);	// list of cell positions in a random order.
			for (int i=0; i<randomPositions.length; i++) {
				int position = randomPositions[i];
				int row = position/size;
				int col = position%size;

				String cell = puzzle[row][col];
				boolean unoccupied = (cell.equals(Common.DOT));

				if (unoccupied) {
					// Before filling a value to this cell, we need to make sure
					// that we won't create a new redundancy, so we need to check
					// all triplets involving this cell and make sure that no triplet
					// has 2 occupied cells (that will create redundancy when third cell is filled).
					ArrayList<String[]> triplets = Helper.getTriplets(puzzle, row, col);

					boolean willBeRedundant = false;
					for (String[] triplet : triplets) {
						String first = triplet[0], middle = triplet[1], last = triplet[2];

						int occupiedCells = 0;

						if (!first.equals(Common.DOT)) occupiedCells++;
						if (!middle.equals(Common.DOT)) occupiedCells++;
						if (!last.equals(Common.DOT)) occupiedCells++;

						if (occupiedCells==2) {
							willBeRedundant = true;
							break;
						}
					}

					// If redundancy won't be created, fill the cell with the corresponding value of the cell
					// at the same position in the solution grid and continue with the next compensate position.
					if (!willBeRedundant) {
						// Create a copy grid of the puzzle grid and work on the copy rather the original grid.
						String[][] puzzleCopy = Helper.deepCopyOfGrid(puzzle);

						puzzleCopy[row][col] = solution[row][col];
						// if (ANALYZE_MODE) System.out.printf("Compensate cell at row %d, col %d\n", row, col);
						finish = compensate(puzzleCopy, solution, numOfGivens, compensateNum-1, level, puzzles, excludeList);	 // continue compensating next position.
						if (finish) break;
					}
				}
			}
		}

		return finish;
	}

	/*
	 *	Checks if the puzzle has unique solution and has a percent of parsed cells within the input range.
	 * 	Parameters:
	 *		(String[][]) puzzle 	the puzzle to examine
	 *		(Common.Level) 		level the required level, passing Common.Level.UNGRADED means ignore (all level accepted).
	 *	Return:
	 *		(boolean) true if satisfies all conditions, false otherwise.
	 */
	private static boolean isGoodPuzzle(String[][] puzzle, Common.Level level) {
		boolean isGood = true;

		// First check if the puzzle has unique solution. Note that hasUniqueSolution()
		// will solve the puzzle and store its solving statistic in relevant variables
		// that we get below.
		isGood = isGood && Solver.hasUniqueSolution(puzzle);

		// Check the difficulty level requirement if any.
		if (level != Common.Level.UNGRADED) {      
			// Calculate the level of the newly solved puzzle.
			int size = puzzle.length;
			int parseNum = Solver.numOfParsedCells;
			float parsePercent = (float)parseNum*100/(size*size);
			int lsdNum = Solver.numOfParsedCellsAfterLsd;
			float lsdPercent = (float)lsdNum*100/(size*size);
			int alsdNum = Solver.numOfParsedCellsAfterAlsd;
			float alsdPercent = (float)alsdNum*100/(size*size);

			// Get the enum Size corresponding to the puzzle size.
	        Common.Size enumSize = null;
	        for (Common.Size eS : Common.Size.values()) {
	            if (size == eS.getCode()) {
	                enumSize = eS;
	                break;
	            }
	        }
			Common.Level l = Solver.gradePuzzle(enumSize, parsePercent, lsdPercent, alsdPercent);
			isGood = isGood && (level == l); 	// check if the puzzle has the desired difficulty level.
		}

		return isGood;
	}

}
