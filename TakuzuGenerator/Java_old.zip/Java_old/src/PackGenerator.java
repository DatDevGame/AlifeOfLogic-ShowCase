    /*************************************************************************
 *  File:	PackGenerator.java
 *	Class: PackGenerator
 *
 *  Generates puzzle pack as per the input requirements.
 *
 *************************************************************************/
import com.sonpt.colorplace.*;
import java.util.*;
import java.sql.*;

public class PackGenerator {

    /*
     *  Generates puzzle packs as per the input requirements.
     *  Parameters:
     *      (String)    packName    name of the pack to create
     *      (String)    sizesStr    list of code number of puzzle sizes to include in the pack, comma separated
     *      (String)    levelsStr   list of code number of puzzle levels per size to include in the pack, comma separated
     *      (int)       puzzleNum   number of puzzles/level/size to add to the pack
     *      (String)    packDb      Filepath to the generated pack db.
     *      (String)    allPacksDb  Filepath to the packs-compile db.
     *      (String)    sourceDb    Filepath to the puzzle source db.
     *  Sample Terminal cmd (Mac): 
     *      Basic: java -classpath ".:sqlite-jdbc-3.8.7.jar" PackGenerator Basic 6,8,10,12 0,1,2 100 ../raw_packs/basic.db ../raw_packs/allpacks.db ../data/puzzles.db
     *      Standard: java -classpath ".:sqlite-jdbc-3.8.7.jar" PackGenerator Standard 6,8,10,12 0,1,2,3 50 ../raw_packs/standard.db ../raw_packs/allpacks.db ../data/puzzles.db
     *      Easy: java -classpath ".:sqlite-jdbc-3.8.7.jar" PackGenerator Easy 6,8,10,12 0 100 ../raw_packs/easy.db ../raw_packs/allpacks.db ../data/puzzles.db
     *      Medium: java -classpath ".:sqlite-jdbc-3.8.7.jar" PackGenerator Medium 6,8,10,12 1 100 ../raw_packs/medium.db ../raw_packs/allpacks.db ../data/puzzles.db
     *      Hard: java -classpath ".:sqlite-jdbc-3.8.7.jar" PackGenerator Hard 6,8,10,12 2 100 ../raw_packs/hard.db ../raw_packs/allpacks.db ../data/puzzles.db
     *      Evil: java -classpath ".:sqlite-jdbc-3.8.7.jar" PackGenerator Evil 6,8,10,12 3 100 ../raw_packs/evil.db ../raw_packs/allpacks.db ../data/puzzles.db
     */
    public static void main(String[] args) {
        String packName = args[0];
        String sizesStr = args[1];
        String levelsStr = args[2];
        int puzzleNum = Integer.parseInt(args[3]);
        String packDb = args[4];        
        String allPacksDb = args[5];    
        String sourceDb = args[6];      

        System.out.println("===========================================================");
        System.out.printf("Creating %s pack with required sizes: %s, required levels: %s\n",packName, sizesStr, levelsStr);
        System.out.println("===========================================================");

        // Measure runtime.
        long startTime = System.currentTimeMillis();

        // Parse the sizesStr into an string array and then convert to a Common.Size array.
        String[] sizesStrArray = sizesStr.split(",");
        int numOfSizes = sizesStrArray.length;
        Common.Size[] sizes = new Common.Size[numOfSizes];
        for (int i=0; i<numOfSizes; i++) {
            int sizeCode = Integer.parseInt(sizesStrArray[i]);
            for (Common.Size size : Common.Size.values()) {
                if (sizeCode == size.getCode()) {
                    sizes[i] = size;
                    break;
                }
            }
        }

        // Init the source database of puzzles.
        try {
            Data.init(sourceDb);
        } catch (ClassNotFoundException e) {
            System.err.println(e.getMessage());
        }

        // Init the pack database and the "allpacks" database.
        Connection packConn = null, allPacksConn = null;
        try {
            packConn = PackData.initPack(packDb);               // create a new db file for the pack.
            allPacksConn = PackData.initPack(allPacksDb);       // connect the database containing all packs.
        } catch (ClassNotFoundException e) {
            System.err.println(e.getMessage());
        }
        
        // Loop thru all the required sizes and corresponding levels and pick relevant puzzles
        // from the sources to insert into our new pack database and the (compile) allpacks database.
        int totalRequiredPuzzles = 0;
        int totalAddedPuzzles = 0;
        for (Common.Size size : sizes) {
            
            // Parse the levelsStr into an string array and then convert to a Common.Level array.
            String[] levelsStrArray = levelsStr.split(",");
            int numOfLevels = levelsStrArray.length;
            Common.Level[] levels = new Common.Level[numOfLevels];
            for (int j=0; j<numOfLevels; j++) {
                String levelNameCode = levelsStrArray[j];
                // Get the corresponding levelName from the enum.
                Common.LevelName levelName = null;
                for (Common.LevelName ln : Common.LevelName.values()) {
                    if (levelNameCode.equals(ln.getCode())) {
                        levelName = ln;
                        break;
                    }
                }

                if (levelName != null) {
                    String levelCode = Common.constructLevelCode(size, levelName);
                    for (Common.Level level : Common.Level.values()) {
                        if ((size.getCode() == level.getSizeCode()) && (levelCode.equals(level.getCode()))) {
                            levels[j] = level;
                            break;
                        }
                    }
                }   
            }

            // Increase the total required by the number of puzzles required for this size.
            totalRequiredPuzzles += levels.length*puzzleNum;

            for (Common.Level level : levels) {
                System.out.printf("Adding puzzles of size: %d, level: %s\n", size.getCode(), level);

                // Get the id list of puzzle of the specified size & level from the library.
                ArrayList<Integer> idList = Data.getListOfPuzzleId(size, level);

                // Create a random list of indices so that we can get puzzles from the library in a random order.
                int[] shuffledIndices = Helper.createShuffleList(idList.size());

                // Now we need to pick puzzles from the pool, one-by-one, and check to make sure that
                // it doesn't repeat another puzzle that was already added to a previous pack. Then
                // we insert it to the new pack and to the compiled pack (allPacks) as well.
                int pNumber = PackData.getPuzzlesNumber(packConn, size, level) + 1;
                int addedPuzzles = 0;
                for (int k=0; k<shuffledIndices.length; k++) {

                    // Get a random puzzle from the id list of satisfied puzzles.
                    int index = idList.get(shuffledIndices[k]);
                    Puzzle newPuzzle = Data.getPuzzleById(size, index);
                    
                    // Now check if the new puzzle repeat another puzzle added to a previous pack.
                    boolean repeat = false;

                    // Get all the puzzles of the specified size & level that were added to previous packs.
                    ArrayList<Puzzle> usedPuzzles = PackData.getPuzzles(allPacksConn, size, level);

                    for (Puzzle usedPuzzle : usedPuzzles) {
                        boolean same = newPuzzle.puzzle.equals(usedPuzzle.puzzle);  // check if the two puzzle strings are the same.
                        if (same) {
                            repeat = true;
                            System.out.println("Repeat puzzle detected! Discarding...");
                            break;
                        }
                    }

                    // Insert the new puzzle to the new pack and the compile pack if not repeat.
                    if (!repeat) {
                        PackData.insertPuzzleToPack(packConn, packName, pNumber, newPuzzle);
                        PackData.insertPuzzleToPack(allPacksConn, packName, pNumber, newPuzzle);
                        System.out.printf("Added puzzle #: %d        \r", pNumber);
                        pNumber++;
                        addedPuzzles++;
                        totalAddedPuzzles++;
                    }

                    // Break the loop when we have added the required number of puzzle for each pair of size & level values.
                    if (addedPuzzles>=puzzleNum) break;
                }
            }
        }

        // Update the packs' info tables.
        PackData.updatePackInfo(packConn);
        PackData.updatePackInfo(allPacksConn);

        // Overly careful: check if there's any repeat puzzle in the all_packs database.
        ArrayList<Puzzle> allPuzzles = PackData.getPuzzles(allPacksConn);
        System.out.println("Now check for repeat puzzles in the all_packs database...");
        boolean repeatPuzzle = Validator.repeatPuzzleCheck(allPuzzles);

        // Calculate some result statistic.
        int packPuzzles = PackData.getPuzzlesNumber(packConn);
        int allPacksPuzzles = PackData.getPuzzlesNumber(allPacksConn);

        // Calculate runtime.
        long stopTime = System.currentTimeMillis();
        long elapsedTime = stopTime - startTime;
        String runtime = Helper.formatTime(elapsedTime);

        System.out.println("\n===========================================================");
        System.out.println("Finished creating pack. Statistics:");
        System.out.printf("\nPack name:\t\t%s", packName);
        System.out.printf("\nRequired sizes:\t\t%s", sizesStr);
        System.out.printf("\nRequired levels:\t%s", levelsStr);
        System.out.printf("\nPuzzles/level/size:\t%d", puzzleNum);
        System.out.printf("\nTotal puzzles required:\t%d", totalRequiredPuzzles);
        System.out.printf("\nPuzzles added to pack:\t%d (%.2f%%)", totalAddedPuzzles, (float)totalAddedPuzzles*100/totalRequiredPuzzles);
        System.out.printf("\nTotal pack puzzles:\t%d", packPuzzles);
        System.out.printf("\nAll packs puzzles:\t%d", allPacksPuzzles);
        System.out.printf("\nPack file:\t\t%s", packDb);
        System.out.printf("\nAll_packs file:\t\t%s", allPacksDb);
        System.out.printf("\nPuzzles source file:\t%s", sourceDb);
        System.out.printf("\nRepeat puzzle check:\t%s", (!repeatPuzzle)? "Pass" : "Fail");
        System.out.printf("\nTime:\t\t\t%s", runtime);
        System.out.println("\n===========================================================");

        // Close database connections.
        Data.closeDatabase();
        PackData.closeDatabase(packConn);
        PackData.closeDatabase(allPacksConn);
    }
}
