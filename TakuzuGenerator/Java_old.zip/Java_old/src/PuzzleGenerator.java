/*************************************************************************
 *  File:	PuzzleGenerator.java
 *	Class: PuzzleGenerator
 *
 *  Generates valid puzzles and writes to database..
 *
 *************************************************************************/
import com.sonpt.colorplace.*;
import java.util.*;

public class PuzzleGenerator {

    /*
     *  Generates valid puzzles according to the input requirements. The following
     *  parameters are to be passed in the exact order they are presented.
     *      (int)   gridSize    the size of the puzzle to generate
     *      (int)   givenNum    number of givens of the puzzle
     *      (int)   levelNameCode       [0-4] the target level of the puzzle, -1 means ignore (accept any level)
     *      (int)   gridNum     number of solution grids to take randomly from the solutions database from which puzzles are generated, -1 means all
     *      (int)   puzzlePerGrid   number of puzzles to generate from one solution grid
     *      (int)   totalPuzzleNum   total number of puzzles to generate, stop when reaching this number
     *      (int)   maxAttempts maximum number of attempts to generate puzzlePerGrid puzzles from one solution grid
     *      (int)   maxTrials   maximum number of trials per attempt
     *      (int)   printNum    number of puzzles to be printed to the console at the end of the program
     *      (String)    solutionsDb     relative filepath of the solutions database file
     *      (String)    puzzlesDb       relative filepath of the puzzles database file
     *
     *  Recommended maxTrials for each puzzle size:
     *      Size            maxTrials
     *      6x6             150
     *      8x8             200
     *      10x10           220
     *      12x12           250
     *      14x14           300
     *      16x16           350
     *      18x18           400
     *
     *  Given number range to generatefor each puzzle size:
     *      Size            Given range
     *      6x6             6-12
     *      8x8             12-18
     *      10x10           16-26
     *      12x12           26-36
     *      14x14           38-54
     *      16x16           ---
     *      18x18           ---
     *
     * Sample Terminal cmd (Mac): java -classpath ".:sqlite-jdbc-3.8.7.jar" PuzzleGenerator 6 6 -1 -1 1 10 5000 150 1 ../data/solutions.db ../data/puzzles.db
     */
    public static void main(String[] args) {
        int gridSize = Integer.parseInt(args[0]);
        int givenNum = Integer.parseInt(args[1]);
        String levelNameCode = args[2];
        int gridNum = Integer.parseInt(args[3]);
        int puzzlePerGrid = Integer.parseInt(args[4]);
        int totalPuzzleNum = Integer.parseInt(args[5]);
        int maxAttempts = Integer.parseInt(args[6]);
        int maxTrials = Integer.parseInt(args[7]);
        int printNum = Integer.parseInt(args[8]);
        String solutionsDb = args[9];
        String puzzlesDb = args[10];

        // Get the enum Size corresponding to the input.
        Common.Size enumSize = null;
        for (Common.Size size : Common.Size.values()) {
            if (gridSize == size.getCode()) {
                enumSize = size;
                break;
            }
        }

        assert (enumSize!=null);

        // Get the enum LevelName corresponding to the input.
        Common.LevelName levelName = null;
        if (Integer.parseInt(levelNameCode) < 0) {
            levelName = Common.LevelName.UNGRADED;
        } else {
            for (Common.LevelName ln : Common.LevelName.values()) {
                if (levelNameCode.equals(ln.getCode())) {
                    levelName = ln;
                    break;
                }
            }
        }

        assert (levelName!=null);

        // Now find the corresponding Common.Level value.
        Common.Level level = Common.getLevel(enumSize, levelName);

        // Get the solutions from database.
        ArrayList<String> solutions = null;
        try {
            Data.init(solutionsDb);
            solutions = Data.getAllSolutions(enumSize);
            Data.closeDatabase();
        } catch (ClassNotFoundException e) {
            System.err.println(e.getMessage());
        }

        if (solutions.size()<=0) {
            System.out.println("ERROR: No solution grids found. Aborting...");
            System.exit(-1);
        }

        System.out.printf("\nGenerating %d x %d puzzles with %d givens...\n", gridSize, gridSize, givenNum);

        // Init the puzzles database.
        try {
            Data.init(puzzlesDb);
        } catch (ClassNotFoundException e) {
            System.err.println(e.getMessage());
        }

        ArrayList<Puzzle> excludePuzzles = Data.getAllPuzzles(enumSize, givenNum);

        // Measure runtime.
        long startTime = System.currentTimeMillis();

        // Determine the number of grids to generate puzzles from.
        int numOfGrids = (gridNum<0 || gridNum>solutions.size())? solutions.size() : gridNum;

        // Create a shuffle list to get solutions in a random order. We'll use the first numOfGrids elements of this list.
        int[] shuffleList = Helper.createShuffleList(solutions.size());

        int newPuzzles = 0;
        for (int i=0; i<numOfGrids; i++) {
            // Display progress.
            System.out.println("===========================================================");
            System.out.printf("Generating puzzles for grid %d of %d; Total puzzles created: %d      \n",i+1, numOfGrids, newPuzzles);

            int index = shuffleList[i];     // get the random index from the shuffle list.
            String[][] grid = Helper.puzzleStringToStringGrid(solutions.get(index));    // get random solution grid.
            ArrayList<Puzzle> puzzles = Generator.createPuzzles(grid, givenNum, level, puzzlePerGrid, excludePuzzles, maxAttempts, (long)maxTrials, true);
            Data.insertPuzzles(enumSize, puzzles);  // store to database
            
            newPuzzles += puzzles.size();
            if (newPuzzles >= totalPuzzleNum) break;
        }

        ArrayList<Puzzle> storedPuzzles = Data.getAllPuzzles(enumSize, givenNum);
        System.out.println("\nNow check for repeat puzzles in the database...");
        boolean repeatPuzzle = Validator.repeatPuzzleCheck(storedPuzzles);

        // Calculate runtime.
        long stopTime = System.currentTimeMillis();
        long elapsedTime = stopTime - startTime;
        String runtime = Helper.formatTime(elapsedTime);

        System.out.println("\n===========================================================");
        System.out.println("Finished creating puzzles. Statistics:");
        System.out.printf("\nPuzzles specs:\t\t\tsize %dx%d, %d givens, level %s", gridSize, gridSize, givenNum, levelNameCode);
        System.out.printf("\nGrids number:\t\t\t%d", gridNum);
        System.out.printf("\nRequired puzzles/grid:\t\t%d", puzzlePerGrid);
        System.out.printf("\nTotal puzzles expected:\t\t%d", totalPuzzleNum);
        System.out.printf("\nPuzzles created:\t\t%d (%.2f%%)", newPuzzles, (float)newPuzzles*100/totalPuzzleNum);
        System.out.printf("\nMax attempts/grid:\t\t%d", maxAttempts);
        System.out.printf("\nMax trials/attempt:\t\t%d", maxTrials);
        System.out.printf("\nRepeat puzzle checking result:\t%s", (!repeatPuzzle)? "Pass" : "Fail");
        System.out.printf("\nTime:\t\t\t\t%s", runtime);
        System.out.println("\n===========================================================");

        // Close database.
        Data.closeDatabase();
    }

}
