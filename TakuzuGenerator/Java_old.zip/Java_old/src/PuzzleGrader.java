/*************************************************************************
 *  File:	PuzzleGrader.java
 *	Class: PuzzleGrader
 *
 *  Grades the puzzles in the database and update the database.
 *
 *************************************************************************/
import com.sonpt.colorplace.*;
import java.util.*;
import java.util.Arrays;
import java.util.ArrayList;

public class PuzzleGrader {

    /*
     *  (Optionally) resolve and grade all puzzles in the given database (and then update the database).
     *      (int)    solve          whether to re-solve the puzzle before grading it, >0 means yes, <=0 means no
     *      (int)    puzzleSize     the size of the puzzles to be graded, -1 means all
     *      (int)    puzzleNum      number of puzzle per size to update, counting from id=0, -1 means all
     *      (String) puzzlesDb      relative filepath of the puzzles database file
     *
     *  Sample Terminal cmd (Mac): java -classpath ".:sqlite-jdbc-3.8.7.jar" PuzzleGrader 1 12 -1 ../data/puzzles.db
     */
    public static void main(String[] args) {
        boolean solvePuzzle = (Integer.parseInt(args[0]) > 0) ? true : false;
        int puzzleSize = Integer.parseInt(args[1]);
        int puzzleNum = Integer.parseInt(args[2]);
        String puzzlesDb = args[3];

        // Init the puzzles database.
        try {
            Data.init(puzzlesDb);
        } catch (ClassNotFoundException e) {
            System.err.println(e.getMessage());
        }

        // Loop thru all the available puzzle sizes and update corresponding database table. 
        for (Common.Size size : Common.Size.values()) {
            if ((puzzleSize < 0) || ((puzzleSize >= 0) && (puzzleSize == size.getCode()))) {
                System.out.printf("\nUpdate puzzles of size %dx%d...\n", size.getCode(), size.getCode());

                // Get the list of all ids of the current puzzle size from the database.
                ArrayList<Integer> idList = Data.getListOfPuzzleId(size);

                // Now loop thru all the puzzles.
                for (int i=0; i<idList.size(); i++) {

                    System.out.printf("Updating puzzle %d of %d      \r", i+1, idList.size());

                    // Get the id.
                    int id = idList.get(i);

                    // Get the puzzle record.
                    Puzzle puzzle = Data.getPuzzleById(size, id);

                    // Since the fields of Puzzle class are final and can't be change, we'll need to create a new puzzle instance.
                    int sz = puzzle.size;
                    String p = puzzle.puzzle;
                    String s = puzzle.solution;
                    int gn = puzzle.givenNum;
                    int pn = puzzle.parseNum;
                    float pp = puzzle.parsePercent;
                    int lsdn = puzzle.lsdNum;
                    float lsdp = puzzle.lsdPercent;
                    int alsdn = puzzle.alsdNum;
                    float alsdp = puzzle.alsdPercent;
                    String l = puzzle.level;

                    // Solve the puzzle if desired.
                    if (solvePuzzle) {
                        String[][] puzzleGrid = Helper.puzzleStringToStringGrid(puzzle.puzzle);
                        ArrayList<String[][]> solutions = Solver.solve(puzzleGrid, 1, true, true, true);  // useLSD: true; useALSD: true; silent: true

                        // Now update the puzzle with new solving results.
                        s = Helper.puzzleStringGridToString(solutions.get(0));

                        pn = Solver.numOfParsedCells;
                        pp = (float)pn*100/(sz*sz);

                        lsdn = Solver.numOfParsedCellsAfterLsd;    // LSD
                        lsdp = (float)lsdn*100/(sz*sz);

                        alsdn = Solver.numOfParsedCellsAfterAlsd;  // ALSD
                        alsdp = (float)alsdn*100/(sz*sz);
                    }

                    // Now grade the puzzle.
                    l = Solver.gradePuzzle(size, pp, lsdp, alsdp).getCode();

                    // Construct new puzzle instance.
                    Puzzle newPuzzle = new Puzzle(sz, p, s, gn, pn, pp, lsdn, lsdp, alsdn, alsdp, l);

                    // Finally update the puzzle record in database.
                    Data.updatePuzzle(size, id, newPuzzle);

                    if (i==(puzzleNum-1)) break;
                }
            } 
        }

        System.out.println("\nProcess completed.");

        // Close database.
        Data.closeDatabase();
    }

}
