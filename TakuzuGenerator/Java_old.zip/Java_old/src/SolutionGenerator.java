/*************************************************************************
 *  File:	SolutionGenerator.java
 *	Class: SolutionGenerator
 *
 *  Generates valid solutions and writes to database..
 *
 *************************************************************************/
import com.sonpt.colorplace.*;
import java.util.*;

public class SolutionGenerator {

    /*
     *  Generates valid solution grids according to the input requirements. The following
     *  parameters are to be passed in the exact order they are presented.
     *      (int)   gridSize    the size of the solution grid to generate
     *      (int)   numOfGrids  number of grids to generate
     *      (int)   maxAttempts maximum number of attempts to generate the required number of solutions, -1 means no limit, 0 is illegal
     *      (int)   maxTrials   maximum number of trials per attempt
     *      (int)   printNum    number of solution grids to be printed to the console at the end of the program
     *      (String)    filepath     relative filepath of the solutions database file
     *
     *  Recommended maxTrials for each puzzle size:
     *      Size            maxTrials
     *      6x6             300
     *      8x8             500
     *      10x10           800
     *      12x12           1000
     *      14x14           1200
     *      16x16           1500
     *      18x18           1700
     *  java -classpath ".:sqlite-jdbc-3.8.7.jar" SolutionGenerator 6 10 -1 300 0 ../data/solutions.db
     */
    public static void main(String[] args) {
        int gridSize = Integer.parseInt(args[0]);
        int numOfGrids = Integer.parseInt(args[1]);
        int maxAttempts = Integer.parseInt(args[2]);
        int maxTrials = Integer.parseInt(args[3]);
        int printNum = Integer.parseInt(args[4]);
        String filepath = args[5];

        final int VALUE_1 = Integer.parseInt(Common.VALUE_1);
        final int VALUE_2 = Integer.parseInt(Common.VALUE_2);

        // Get the enum Size corresponding to the input.
        Common.Size enumSize = null;
        for (Common.Size size : Common.Size.values()) {
            if (gridSize == size.getCode()) {
                enumSize = size;
                break;
            }
        }

        // Init the database.
        try {
            Data.init(filepath);
        } catch (ClassNotFoundException e) {
            System.err.println(e.getMessage());
        }

        ArrayList<String> excludeGrids = Data.getAllSolutions(enumSize);    // exclude all existing grids at the same size in the database.
        ArrayList<String> listOfGrids = Filler.formValidGrids(enumSize.getCode(), VALUE_1, VALUE_2, numOfGrids, maxAttempts, maxTrials, excludeGrids);

        // Store new solutions to database.
        Data.insertSolutions(enumSize, listOfGrids);

        ArrayList<String> storedGrids = Data.getAllSolutions(enumSize);
        
        System.out.println("Now check for repeat solutions in the database...");
        boolean repeatSolution = Validator.repeatStringCheck(storedGrids);

        // Print created grids to the console.
        int numToPrint = (printNum<0)? listOfGrids.size() : (printNum > listOfGrids.size())? listOfGrids.size() : printNum;
        System.out.println("List of constructed grids:");
        System.out.println("===========================================================");
        for (int i=0; i<numToPrint; i++) {
            String[][] grid = Helper.puzzleStringToStringGrid(listOfGrids.get(i));
            boolean validated = Validator.validateGrid(grid, Common.VALUE_1, Common.VALUE_2);
            System.out.printf("Grid number: %d (validated: %b)\n", i+1, validated);            
            Helper.printGrid(grid);
            System.out.println("===========================================================");
        }

        // Close database.
        Data.closeDatabase();
    }

}
